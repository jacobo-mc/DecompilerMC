/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.gui.narration;

import net.minecraft.client.gui.narration.NarrationSupplier;

public interface NarratableEntry
extends NarrationSupplier {
    public NarrationPriority narrationPriority();

    default public boolean isActive() {
        return true;
    }

    public static final class NarrationPriority
    extends Enum<NarrationPriority> {
        public static final /* enum */ NarrationPriority NONE = new NarrationPriority();
        public static final /* enum */ NarrationPriority HOVERED = new NarrationPriority();
        public static final /* enum */ NarrationPriority FOCUSED = new NarrationPriority();
        private static final /* synthetic */ NarrationPriority[] $VALUES;

        public static NarrationPriority[] values() {
            return (NarrationPriority[])$VALUES.clone();
        }

        public static NarrationPriority valueOf(String string) {
            return Enum.valueOf(NarrationPriority.class, string);
        }

        public boolean isTerminal() {
            return this == FOCUSED;
        }

        private static /* synthetic */ NarrationPriority[] $values() {
            return new NarrationPriority[]{NONE, HOVERED, FOCUSED};
        }

        static {
            $VALUES = NarrationPriority.$values();
        }
    }

}

