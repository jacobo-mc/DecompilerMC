/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.gui.screens.recipebook;

import java.util.List;
import net.minecraft.world.item.crafting.Recipe;

public interface RecipeShownListener {
    public void recipesShown(List<Recipe<?>> var1);
}

