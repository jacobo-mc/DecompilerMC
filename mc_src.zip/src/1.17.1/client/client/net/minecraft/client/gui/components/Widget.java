/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.gui.components;

import com.mojang.blaze3d.vertex.PoseStack;

public interface Widget {
    public void render(PoseStack var1, int var2, int var3, float var4);
}

