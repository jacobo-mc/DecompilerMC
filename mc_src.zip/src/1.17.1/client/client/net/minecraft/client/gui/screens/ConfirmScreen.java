/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  it.unimi.dsi.fastutil.booleans.BooleanConsumer
 */
package net.minecraft.client.gui.screens;

import com.google.common.collect.Lists;
import com.mojang.blaze3d.vertex.PoseStack;
import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.MultiLineLabel;
import net.minecraft.client.gui.components.Widget;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.Mth;

public class ConfirmScreen
extends Screen {
    private static final int LABEL_Y = 90;
    private final Component title2;
    private MultiLineLabel message = MultiLineLabel.EMPTY;
    protected Component yesButton;
    protected Component noButton;
    private int delayTicker;
    protected final BooleanConsumer callback;
    private final List<Button> exitButtons = Lists.newArrayList();

    public ConfirmScreen(BooleanConsumer booleanConsumer, Component component, Component component2) {
        this(booleanConsumer, component, component2, CommonComponents.GUI_YES, CommonComponents.GUI_NO);
    }

    public ConfirmScreen(BooleanConsumer booleanConsumer, Component component, Component component2, Component component3, Component component4) {
        super(component);
        this.callback = booleanConsumer;
        this.title2 = component2;
        this.yesButton = component3;
        this.noButton = component4;
    }

    @Override
    public Component getNarrationMessage() {
        return CommonComponents.joinForNarration(super.getNarrationMessage(), this.title2);
    }

    @Override
    protected void init() {
        super.init();
        this.message = MultiLineLabel.create(this.font, (FormattedText)this.title2, this.width - 50);
        Objects.requireNonNull(this.font);
        int n = this.message.getLineCount() * 9;
        int n2 = Mth.clamp(90 + n + 12, this.height / 6 + 96, this.height - 24);
        this.exitButtons.clear();
        this.addButtons(n2);
    }

    protected void addButtons(int n) {
        this.addExitButton(new Button(this.width / 2 - 155, n, 150, 20, this.yesButton, button -> this.callback.accept(true)));
        this.addExitButton(new Button(this.width / 2 - 155 + 160, n, 150, 20, this.noButton, button -> this.callback.accept(false)));
    }

    protected void addExitButton(Button button) {
        this.exitButtons.add(this.addRenderableWidget(button));
    }

    @Override
    public void render(PoseStack poseStack, int n, int n2, float f) {
        this.renderBackground(poseStack);
        ConfirmScreen.drawCenteredString(poseStack, this.font, this.title, this.width / 2, 70, 16777215);
        this.message.renderCentered(poseStack, this.width / 2, 90);
        super.render(poseStack, n, n2, f);
    }

    public void setDelay(int n) {
        this.delayTicker = n;
        for (Button button : this.exitButtons) {
            button.active = false;
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (--this.delayTicker == 0) {
            for (Button button : this.exitButtons) {
                button.active = true;
            }
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public boolean keyPressed(int n, int n2, int n3) {
        if (n == 256) {
            this.callback.accept(false);
            return true;
        }
        return super.keyPressed(n, n2, n3);
    }
}

