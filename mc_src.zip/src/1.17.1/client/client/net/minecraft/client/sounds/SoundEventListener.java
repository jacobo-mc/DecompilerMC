/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.sounds;

import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.WeighedSoundEvents;

public interface SoundEventListener {
    public void onPlaySound(SoundInstance var1, WeighedSoundEvents var2);
}

