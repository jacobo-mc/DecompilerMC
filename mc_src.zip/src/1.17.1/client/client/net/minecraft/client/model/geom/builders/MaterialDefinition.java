/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.model.geom.builders;

public class MaterialDefinition {
    final int xTexSize;
    final int yTexSize;

    public MaterialDefinition(int n, int n2) {
        this.xTexSize = n;
        this.yTexSize = n2;
    }
}

