/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.searchtree;

import java.util.List;

public interface SearchTree<T> {
    public List<T> search(String var1);
}

