/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.gui.narration;

import net.minecraft.client.gui.narration.NarrationElementOutput;

public interface NarrationSupplier {
    public void updateNarration(NarrationElementOutput var1);
}

