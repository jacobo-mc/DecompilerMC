/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client;

import java.util.Arrays;
import java.util.Comparator;
import java.util.function.IntFunction;
import java.util.stream.Stream;
import net.minecraft.util.Mth;

public final class AmbientOcclusionStatus
extends Enum<AmbientOcclusionStatus> {
    public static final /* enum */ AmbientOcclusionStatus OFF = new AmbientOcclusionStatus(0, "options.ao.off");
    public static final /* enum */ AmbientOcclusionStatus MIN = new AmbientOcclusionStatus(1, "options.ao.min");
    public static final /* enum */ AmbientOcclusionStatus MAX = new AmbientOcclusionStatus(2, "options.ao.max");
    private static final AmbientOcclusionStatus[] BY_ID;
    private final int id;
    private final String key;
    private static final /* synthetic */ AmbientOcclusionStatus[] $VALUES;

    public static AmbientOcclusionStatus[] values() {
        return (AmbientOcclusionStatus[])$VALUES.clone();
    }

    public static AmbientOcclusionStatus valueOf(String string) {
        return Enum.valueOf(AmbientOcclusionStatus.class, string);
    }

    private AmbientOcclusionStatus(int n2, String string2) {
        this.id = n2;
        this.key = string2;
    }

    public int getId() {
        return this.id;
    }

    public String getKey() {
        return this.key;
    }

    public static AmbientOcclusionStatus byId(int n) {
        return BY_ID[Mth.positiveModulo(n, BY_ID.length)];
    }

    private static /* synthetic */ AmbientOcclusionStatus[] $values() {
        return new AmbientOcclusionStatus[]{OFF, MIN, MAX};
    }

    static {
        $VALUES = AmbientOcclusionStatus.$values();
        BY_ID = (AmbientOcclusionStatus[])Arrays.stream(AmbientOcclusionStatus.values()).sorted(Comparator.comparingInt(AmbientOcclusionStatus::getId)).toArray(n -> new AmbientOcclusionStatus[n]);
    }
}

