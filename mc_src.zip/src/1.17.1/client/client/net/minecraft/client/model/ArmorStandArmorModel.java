/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.model;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.core.Rotations;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;

public class ArmorStandArmorModel
extends HumanoidModel<ArmorStand> {
    public ArmorStandArmorModel(ModelPart modelPart) {
        super(modelPart);
    }

    public static LayerDefinition createBodyLayer(CubeDeformation cubeDeformation) {
        MeshDefinition meshDefinition = HumanoidModel.createMesh(cubeDeformation, 0.0f);
        PartDefinition partDefinition = meshDefinition.getRoot();
        partDefinition.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0f, -8.0f, -4.0f, 8.0f, 8.0f, 8.0f, cubeDeformation), PartPose.offset(0.0f, 1.0f, 0.0f));
        partDefinition.addOrReplaceChild("hat", CubeListBuilder.create().texOffs(32, 0).addBox(-4.0f, -8.0f, -4.0f, 8.0f, 8.0f, 8.0f, cubeDeformation.extend(0.5f)), PartPose.offset(0.0f, 1.0f, 0.0f));
        partDefinition.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(0, 16).addBox(-2.0f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f, cubeDeformation), PartPose.offset(-1.9f, 11.0f, 0.0f));
        partDefinition.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(0, 16).mirror().addBox(-2.0f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f, cubeDeformation), PartPose.offset(1.9f, 11.0f, 0.0f));
        return LayerDefinition.create(meshDefinition, 64, 32);
    }

    @Override
    public void setupAnim(ArmorStand armorStand, float f, float f2, float f3, float f4, float f5) {
        this.head.xRot = 0.017453292f * armorStand.getHeadPose().getX();
        this.head.yRot = 0.017453292f * armorStand.getHeadPose().getY();
        this.head.zRot = 0.017453292f * armorStand.getHeadPose().getZ();
        this.body.xRot = 0.017453292f * armorStand.getBodyPose().getX();
        this.body.yRot = 0.017453292f * armorStand.getBodyPose().getY();
        this.body.zRot = 0.017453292f * armorStand.getBodyPose().getZ();
        this.leftArm.xRot = 0.017453292f * armorStand.getLeftArmPose().getX();
        this.leftArm.yRot = 0.017453292f * armorStand.getLeftArmPose().getY();
        this.leftArm.zRot = 0.017453292f * armorStand.getLeftArmPose().getZ();
        this.rightArm.xRot = 0.017453292f * armorStand.getRightArmPose().getX();
        this.rightArm.yRot = 0.017453292f * armorStand.getRightArmPose().getY();
        this.rightArm.zRot = 0.017453292f * armorStand.getRightArmPose().getZ();
        this.leftLeg.xRot = 0.017453292f * armorStand.getLeftLegPose().getX();
        this.leftLeg.yRot = 0.017453292f * armorStand.getLeftLegPose().getY();
        this.leftLeg.zRot = 0.017453292f * armorStand.getLeftLegPose().getZ();
        this.rightLeg.xRot = 0.017453292f * armorStand.getRightLegPose().getX();
        this.rightLeg.yRot = 0.017453292f * armorStand.getRightLegPose().getY();
        this.rightLeg.zRot = 0.017453292f * armorStand.getRightLegPose().getZ();
        this.hat.copyFrom(this.head);
    }
}

