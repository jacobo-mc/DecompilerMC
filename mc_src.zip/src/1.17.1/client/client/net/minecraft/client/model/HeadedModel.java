/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.model;

import net.minecraft.client.model.geom.ModelPart;

public interface HeadedModel {
    public ModelPart getHead();
}

