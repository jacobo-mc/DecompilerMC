/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.gui.screens.achievement;

public interface StatsUpdateListener {
    public static final String[] LOADING_SYMBOLS = new String[]{"oooooo", "Oooooo", "oOoooo", "ooOooo", "oooOoo", "ooooOo", "oooooO"};

    public void onStatsUpdated();
}

