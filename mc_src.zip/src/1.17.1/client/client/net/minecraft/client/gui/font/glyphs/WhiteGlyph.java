/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.gui.font.glyphs;

import com.mojang.blaze3d.font.RawGlyph;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.Util;

public final class WhiteGlyph
extends Enum<WhiteGlyph>
implements RawGlyph {
    public static final /* enum */ WhiteGlyph INSTANCE = new WhiteGlyph();
    private static final int WIDTH = 5;
    private static final int HEIGHT = 8;
    private static final NativeImage IMAGE_DATA;
    private static final /* synthetic */ WhiteGlyph[] $VALUES;

    public static WhiteGlyph[] values() {
        return (WhiteGlyph[])$VALUES.clone();
    }

    public static WhiteGlyph valueOf(String string) {
        return Enum.valueOf(WhiteGlyph.class, string);
    }

    @Override
    public int getPixelWidth() {
        return 5;
    }

    @Override
    public int getPixelHeight() {
        return 8;
    }

    @Override
    public float getAdvance() {
        return 6.0f;
    }

    @Override
    public float getOversample() {
        return 1.0f;
    }

    @Override
    public void upload(int n, int n2) {
        IMAGE_DATA.upload(0, n, n2, false);
    }

    @Override
    public boolean isColored() {
        return true;
    }

    private static /* synthetic */ WhiteGlyph[] $values() {
        return new WhiteGlyph[]{INSTANCE};
    }

    static {
        $VALUES = WhiteGlyph.$values();
        IMAGE_DATA = Util.make(new NativeImage(NativeImage.Format.RGBA, 5, 8, false), nativeImage -> {
            for (int i = 0; i < 8; ++i) {
                for (int j = 0; j < 5; ++j) {
                    boolean bl = j == 0 || j + 1 == 5 || i == 0 || i + 1 == 8;
                    nativeImage.setPixelRGBA(j, i, -1);
                }
            }
            nativeImage.untrack();
        });
    }
}

