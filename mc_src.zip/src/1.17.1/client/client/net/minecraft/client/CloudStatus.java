/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client;

public final class CloudStatus
extends Enum<CloudStatus> {
    public static final /* enum */ CloudStatus OFF = new CloudStatus("options.off");
    public static final /* enum */ CloudStatus FAST = new CloudStatus("options.clouds.fast");
    public static final /* enum */ CloudStatus FANCY = new CloudStatus("options.clouds.fancy");
    private final String key;
    private static final /* synthetic */ CloudStatus[] $VALUES;

    public static CloudStatus[] values() {
        return (CloudStatus[])$VALUES.clone();
    }

    public static CloudStatus valueOf(String string) {
        return Enum.valueOf(CloudStatus.class, string);
    }

    private CloudStatus(String string2) {
        this.key = string2;
    }

    public String getKey() {
        return this.key;
    }

    private static /* synthetic */ CloudStatus[] $values() {
        return new CloudStatus[]{OFF, FAST, FANCY};
    }

    static {
        $VALUES = CloudStatus.$values();
    }
}

