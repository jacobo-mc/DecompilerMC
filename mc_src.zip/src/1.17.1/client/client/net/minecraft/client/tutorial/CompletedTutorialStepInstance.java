/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.tutorial;

import net.minecraft.client.tutorial.Tutorial;
import net.minecraft.client.tutorial.TutorialStepInstance;

public class CompletedTutorialStepInstance
implements TutorialStepInstance {
    public CompletedTutorialStepInstance(Tutorial tutorial) {
    }
}

