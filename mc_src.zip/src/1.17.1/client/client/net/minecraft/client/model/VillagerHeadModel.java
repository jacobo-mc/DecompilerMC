/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.model;

public interface VillagerHeadModel {
    public void hatVisible(boolean var1);
}

