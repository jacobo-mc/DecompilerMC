/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  javax.annotation.Nullable
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package net.minecraft.client;

import com.google.common.collect.ImmutableList;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import net.minecraft.CrashReport;
import net.minecraft.CrashReportCategory;
import net.minecraft.CrashReportDetail;
import net.minecraft.server.packs.PackResources;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ResourceLoadStateTracker {
    private static final Logger LOGGER = LogManager.getLogger();
    @Nullable
    private ReloadState reloadState;
    private int reloadCount;

    public void startReload(ReloadReason reloadReason, List<PackResources> list) {
        ++this.reloadCount;
        if (this.reloadState != null && !this.reloadState.finished) {
            LOGGER.warn("Reload already ongoing, replacing");
        }
        this.reloadState = new ReloadState(reloadReason, (List)list.stream().map(PackResources::getName).collect(ImmutableList.toImmutableList()));
    }

    public void startRecovery(Throwable throwable) {
        if (this.reloadState == null) {
            LOGGER.warn("Trying to signal reload recovery, but nothing was started");
            this.reloadState = new ReloadState(ReloadReason.UNKNOWN, (List<String>)ImmutableList.of());
        }
        this.reloadState.recoveryReloadInfo = new RecoveryInfo(throwable);
    }

    public void finishReload() {
        if (this.reloadState == null) {
            LOGGER.warn("Trying to finish reload, but nothing was started");
        } else {
            this.reloadState.finished = true;
        }
    }

    public void fillCrashReport(CrashReport crashReport) {
        CrashReportCategory crashReportCategory = crashReport.addCategory("Last reload");
        crashReportCategory.setDetail("Reload number", this.reloadCount);
        if (this.reloadState != null) {
            this.reloadState.fillCrashInfo(crashReportCategory);
        }
    }

    static class ReloadState {
        private final ReloadReason reloadReason;
        private final List<String> packs;
        @Nullable
        RecoveryInfo recoveryReloadInfo;
        boolean finished;

        ReloadState(ReloadReason reloadReason, List<String> list) {
            this.reloadReason = reloadReason;
            this.packs = list;
        }

        public void fillCrashInfo(CrashReportCategory crashReportCategory) {
            crashReportCategory.setDetail("Reload reason", this.reloadReason.name);
            crashReportCategory.setDetail("Finished", this.finished ? "Yes" : "No");
            crashReportCategory.setDetail("Packs", () -> String.join((CharSequence)", ", this.packs));
            if (this.recoveryReloadInfo != null) {
                this.recoveryReloadInfo.fillCrashInfo(crashReportCategory);
            }
        }
    }

    public static final class ReloadReason
    extends Enum<ReloadReason> {
        public static final /* enum */ ReloadReason INITIAL = new ReloadReason("initial");
        public static final /* enum */ ReloadReason MANUAL = new ReloadReason("manual");
        public static final /* enum */ ReloadReason UNKNOWN = new ReloadReason("unknown");
        final String name;
        private static final /* synthetic */ ReloadReason[] $VALUES;

        public static ReloadReason[] values() {
            return (ReloadReason[])$VALUES.clone();
        }

        public static ReloadReason valueOf(String string) {
            return Enum.valueOf(ReloadReason.class, string);
        }

        private ReloadReason(String string2) {
            this.name = string2;
        }

        private static /* synthetic */ ReloadReason[] $values() {
            return new ReloadReason[]{INITIAL, MANUAL, UNKNOWN};
        }

        static {
            $VALUES = ReloadReason.$values();
        }
    }

    static class RecoveryInfo {
        private final Throwable error;

        RecoveryInfo(Throwable throwable) {
            this.error = throwable;
        }

        public void fillCrashInfo(CrashReportCategory crashReportCategory) {
            crashReportCategory.setDetail("Recovery", "Yes");
            crashReportCategory.setDetail("Recovery reason", () -> {
                StringWriter stringWriter = new StringWriter();
                this.error.printStackTrace(new PrintWriter(stringWriter));
                return stringWriter.toString();
            });
        }
    }

}

