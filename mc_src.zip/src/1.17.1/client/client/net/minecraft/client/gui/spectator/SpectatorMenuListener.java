/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.gui.spectator;

import net.minecraft.client.gui.spectator.SpectatorMenu;

public interface SpectatorMenuListener {
    public void onSpectatorMenuClosed(SpectatorMenu var1);
}

