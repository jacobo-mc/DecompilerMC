/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client;

import java.util.Arrays;
import java.util.Comparator;
import java.util.function.IntFunction;
import java.util.stream.Stream;
import net.minecraft.util.Mth;

public final class ParticleStatus
extends Enum<ParticleStatus> {
    public static final /* enum */ ParticleStatus ALL = new ParticleStatus(0, "options.particles.all");
    public static final /* enum */ ParticleStatus DECREASED = new ParticleStatus(1, "options.particles.decreased");
    public static final /* enum */ ParticleStatus MINIMAL = new ParticleStatus(2, "options.particles.minimal");
    private static final ParticleStatus[] BY_ID;
    private final int id;
    private final String key;
    private static final /* synthetic */ ParticleStatus[] $VALUES;

    public static ParticleStatus[] values() {
        return (ParticleStatus[])$VALUES.clone();
    }

    public static ParticleStatus valueOf(String string) {
        return Enum.valueOf(ParticleStatus.class, string);
    }

    private ParticleStatus(int n2, String string2) {
        this.id = n2;
        this.key = string2;
    }

    public String getKey() {
        return this.key;
    }

    public int getId() {
        return this.id;
    }

    public static ParticleStatus byId(int n) {
        return BY_ID[Mth.positiveModulo(n, BY_ID.length)];
    }

    private static /* synthetic */ ParticleStatus[] $values() {
        return new ParticleStatus[]{ALL, DECREASED, MINIMAL};
    }

    static {
        $VALUES = ParticleStatus.$values();
        BY_ID = (ParticleStatus[])Arrays.stream(ParticleStatus.values()).sorted(Comparator.comparingInt(ParticleStatus::getId)).toArray(n -> new ParticleStatus[n]);
    }
}

