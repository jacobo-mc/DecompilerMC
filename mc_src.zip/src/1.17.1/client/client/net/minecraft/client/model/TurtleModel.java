/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.Iterables
 */
package net.minecraft.client.model;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.QuadrupedModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.animal.Turtle;

public class TurtleModel<T extends Turtle>
extends QuadrupedModel<T> {
    private static final String EGG_BELLY = "egg_belly";
    private final ModelPart eggBelly;

    public TurtleModel(ModelPart modelPart) {
        super(modelPart, true, 120.0f, 0.0f, 9.0f, 6.0f, 120);
        this.eggBelly = modelPart.getChild(EGG_BELLY);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition meshDefinition = new MeshDefinition();
        PartDefinition partDefinition = meshDefinition.getRoot();
        partDefinition.addOrReplaceChild("head", CubeListBuilder.create().texOffs(3, 0).addBox(-3.0f, -1.0f, -3.0f, 6.0f, 5.0f, 6.0f), PartPose.offset(0.0f, 19.0f, -10.0f));
        partDefinition.addOrReplaceChild("body", CubeListBuilder.create().texOffs(7, 37).addBox("shell", -9.5f, 3.0f, -10.0f, 19.0f, 20.0f, 6.0f).texOffs(31, 1).addBox("belly", -5.5f, 3.0f, -13.0f, 11.0f, 18.0f, 3.0f), PartPose.offsetAndRotation(0.0f, 11.0f, -10.0f, 1.5707964f, 0.0f, 0.0f));
        partDefinition.addOrReplaceChild(EGG_BELLY, CubeListBuilder.create().texOffs(70, 33).addBox(-4.5f, 3.0f, -14.0f, 9.0f, 18.0f, 1.0f), PartPose.offsetAndRotation(0.0f, 11.0f, -10.0f, 1.5707964f, 0.0f, 0.0f));
        boolean bl = true;
        partDefinition.addOrReplaceChild("right_hind_leg", CubeListBuilder.create().texOffs(1, 23).addBox(-2.0f, 0.0f, 0.0f, 4.0f, 1.0f, 10.0f), PartPose.offset(-3.5f, 22.0f, 11.0f));
        partDefinition.addOrReplaceChild("left_hind_leg", CubeListBuilder.create().texOffs(1, 12).addBox(-2.0f, 0.0f, 0.0f, 4.0f, 1.0f, 10.0f), PartPose.offset(3.5f, 22.0f, 11.0f));
        partDefinition.addOrReplaceChild("right_front_leg", CubeListBuilder.create().texOffs(27, 30).addBox(-13.0f, 0.0f, -2.0f, 13.0f, 1.0f, 5.0f), PartPose.offset(-5.0f, 21.0f, -4.0f));
        partDefinition.addOrReplaceChild("left_front_leg", CubeListBuilder.create().texOffs(27, 24).addBox(0.0f, 0.0f, -2.0f, 13.0f, 1.0f, 5.0f), PartPose.offset(5.0f, 21.0f, -4.0f));
        return LayerDefinition.create(meshDefinition, 128, 64);
    }

    @Override
    protected Iterable<ModelPart> bodyParts() {
        return Iterables.concat(super.bodyParts(), (Iterable)ImmutableList.of((Object)this.eggBelly));
    }

    @Override
    public void setupAnim(T t, float f, float f2, float f3, float f4, float f5) {
        super.setupAnim(t, f, f2, f3, f4, f5);
        this.rightHindLeg.xRot = Mth.cos(f * 0.6662f * 0.6f) * 0.5f * f2;
        this.leftHindLeg.xRot = Mth.cos(f * 0.6662f * 0.6f + 3.1415927f) * 0.5f * f2;
        this.rightFrontLeg.zRot = Mth.cos(f * 0.6662f * 0.6f + 3.1415927f) * 0.5f * f2;
        this.leftFrontLeg.zRot = Mth.cos(f * 0.6662f * 0.6f) * 0.5f * f2;
        this.rightFrontLeg.xRot = 0.0f;
        this.leftFrontLeg.xRot = 0.0f;
        this.rightFrontLeg.yRot = 0.0f;
        this.leftFrontLeg.yRot = 0.0f;
        this.rightHindLeg.yRot = 0.0f;
        this.leftHindLeg.yRot = 0.0f;
        if (!((Entity)t).isInWater() && ((Entity)t).isOnGround()) {
            float f6 = ((Turtle)t).isLayingEgg() ? 4.0f : 1.0f;
            float f7 = ((Turtle)t).isLayingEgg() ? 2.0f : 1.0f;
            float f8 = 5.0f;
            this.rightFrontLeg.yRot = Mth.cos(f6 * f * 5.0f + 3.1415927f) * 8.0f * f2 * f7;
            this.rightFrontLeg.zRot = 0.0f;
            this.leftFrontLeg.yRot = Mth.cos(f6 * f * 5.0f) * 8.0f * f2 * f7;
            this.leftFrontLeg.zRot = 0.0f;
            this.rightHindLeg.yRot = Mth.cos(f * 5.0f + 3.1415927f) * 3.0f * f2;
            this.rightHindLeg.xRot = 0.0f;
            this.leftHindLeg.yRot = Mth.cos(f * 5.0f) * 3.0f * f2;
            this.leftHindLeg.xRot = 0.0f;
        }
        this.eggBelly.visible = !this.young && ((Turtle)t).hasEgg();
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int n, int n2, float f, float f2, float f3, float f4) {
        boolean bl = this.eggBelly.visible;
        if (bl) {
            poseStack.pushPose();
            poseStack.translate(0.0, -0.07999999821186066, 0.0);
        }
        super.renderToBuffer(poseStack, vertexConsumer, n, n2, f, f2, f3, f4);
        if (bl) {
            poseStack.popPose();
        }
    }
}

