/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.gui.components;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.resources.ResourceLocation;

public class LockIconButton
extends Button {
    private boolean locked;

    public LockIconButton(int n, int n2, Button.OnPress onPress) {
        super(n, n2, 20, 20, new TranslatableComponent("narrator.button.difficulty_lock"), onPress);
    }

    @Override
    protected MutableComponent createNarrationMessage() {
        return CommonComponents.joinForNarration(super.createNarrationMessage(), this.isLocked() ? new TranslatableComponent("narrator.button.difficulty_lock.locked") : new TranslatableComponent("narrator.button.difficulty_lock.unlocked"));
    }

    public boolean isLocked() {
        return this.locked;
    }

    public void setLocked(boolean bl) {
        this.locked = bl;
    }

    @Override
    public void renderButton(PoseStack poseStack, int n, int n2, float f) {
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderTexture(0, Button.WIDGETS_LOCATION);
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        Icon icon = !this.active ? (this.locked ? Icon.LOCKED_DISABLED : Icon.UNLOCKED_DISABLED) : (this.isHovered() ? (this.locked ? Icon.LOCKED_HOVER : Icon.UNLOCKED_HOVER) : (this.locked ? Icon.LOCKED : Icon.UNLOCKED));
        this.blit(poseStack, this.x, this.y, icon.getX(), icon.getY(), this.width, this.height);
    }

    static final class Icon
    extends Enum<Icon> {
        public static final /* enum */ Icon LOCKED = new Icon(0, 146);
        public static final /* enum */ Icon LOCKED_HOVER = new Icon(0, 166);
        public static final /* enum */ Icon LOCKED_DISABLED = new Icon(0, 186);
        public static final /* enum */ Icon UNLOCKED = new Icon(20, 146);
        public static final /* enum */ Icon UNLOCKED_HOVER = new Icon(20, 166);
        public static final /* enum */ Icon UNLOCKED_DISABLED = new Icon(20, 186);
        private final int x;
        private final int y;
        private static final /* synthetic */ Icon[] $VALUES;

        public static Icon[] values() {
            return (Icon[])$VALUES.clone();
        }

        public static Icon valueOf(String string) {
            return Enum.valueOf(Icon.class, string);
        }

        private Icon(int n2, int n3) {
            this.x = n2;
            this.y = n3;
        }

        public int getX() {
            return this.x;
        }

        public int getY() {
            return this.y;
        }

        private static /* synthetic */ Icon[] $values() {
            return new Icon[]{LOCKED, LOCKED_HOVER, LOCKED_DISABLED, UNLOCKED, UNLOCKED_HOVER, UNLOCKED_DISABLED};
        }

        static {
            $VALUES = Icon.$values();
        }
    }

}

