/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client;

import java.util.Arrays;
import java.util.Comparator;
import java.util.function.IntFunction;
import java.util.stream.Stream;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.util.Mth;

public final class NarratorStatus
extends Enum<NarratorStatus> {
    public static final /* enum */ NarratorStatus OFF = new NarratorStatus(0, "options.narrator.off");
    public static final /* enum */ NarratorStatus ALL = new NarratorStatus(1, "options.narrator.all");
    public static final /* enum */ NarratorStatus CHAT = new NarratorStatus(2, "options.narrator.chat");
    public static final /* enum */ NarratorStatus SYSTEM = new NarratorStatus(3, "options.narrator.system");
    private static final NarratorStatus[] BY_ID;
    private final int id;
    private final Component name;
    private static final /* synthetic */ NarratorStatus[] $VALUES;

    public static NarratorStatus[] values() {
        return (NarratorStatus[])$VALUES.clone();
    }

    public static NarratorStatus valueOf(String string) {
        return Enum.valueOf(NarratorStatus.class, string);
    }

    private NarratorStatus(int n2, String string2) {
        this.id = n2;
        this.name = new TranslatableComponent(string2);
    }

    public int getId() {
        return this.id;
    }

    public Component getName() {
        return this.name;
    }

    public static NarratorStatus byId(int n) {
        return BY_ID[Mth.positiveModulo(n, BY_ID.length)];
    }

    private static /* synthetic */ NarratorStatus[] $values() {
        return new NarratorStatus[]{OFF, ALL, CHAT, SYSTEM};
    }

    static {
        $VALUES = NarratorStatus.$values();
        BY_ID = (NarratorStatus[])Arrays.stream(NarratorStatus.values()).sorted(Comparator.comparingInt(NarratorStatus::getId)).toArray(n -> new NarratorStatus[n]);
    }
}

