/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.resources.model;

import com.mojang.math.OctahedralGroup;
import com.mojang.math.Quaternion;
import com.mojang.math.Transformation;
import com.mojang.math.Vector3f;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import net.minecraft.client.resources.model.ModelState;
import net.minecraft.util.Mth;

public final class BlockModelRotation
extends Enum<BlockModelRotation>
implements ModelState {
    public static final /* enum */ BlockModelRotation X0_Y0 = new BlockModelRotation(0, 0);
    public static final /* enum */ BlockModelRotation X0_Y90 = new BlockModelRotation(0, 90);
    public static final /* enum */ BlockModelRotation X0_Y180 = new BlockModelRotation(0, 180);
    public static final /* enum */ BlockModelRotation X0_Y270 = new BlockModelRotation(0, 270);
    public static final /* enum */ BlockModelRotation X90_Y0 = new BlockModelRotation(90, 0);
    public static final /* enum */ BlockModelRotation X90_Y90 = new BlockModelRotation(90, 90);
    public static final /* enum */ BlockModelRotation X90_Y180 = new BlockModelRotation(90, 180);
    public static final /* enum */ BlockModelRotation X90_Y270 = new BlockModelRotation(90, 270);
    public static final /* enum */ BlockModelRotation X180_Y0 = new BlockModelRotation(180, 0);
    public static final /* enum */ BlockModelRotation X180_Y90 = new BlockModelRotation(180, 90);
    public static final /* enum */ BlockModelRotation X180_Y180 = new BlockModelRotation(180, 180);
    public static final /* enum */ BlockModelRotation X180_Y270 = new BlockModelRotation(180, 270);
    public static final /* enum */ BlockModelRotation X270_Y0 = new BlockModelRotation(270, 0);
    public static final /* enum */ BlockModelRotation X270_Y90 = new BlockModelRotation(270, 90);
    public static final /* enum */ BlockModelRotation X270_Y180 = new BlockModelRotation(270, 180);
    public static final /* enum */ BlockModelRotation X270_Y270 = new BlockModelRotation(270, 270);
    private static final int DEGREES = 360;
    private static final Map<Integer, BlockModelRotation> BY_INDEX;
    private final Transformation transformation;
    private final OctahedralGroup actualRotation;
    private final int index;
    private static final /* synthetic */ BlockModelRotation[] $VALUES;

    public static BlockModelRotation[] values() {
        return (BlockModelRotation[])$VALUES.clone();
    }

    public static BlockModelRotation valueOf(String string) {
        return Enum.valueOf(BlockModelRotation.class, string);
    }

    private static int getIndex(int n, int n2) {
        return n * 360 + n2;
    }

    private BlockModelRotation(int n2, int n3) {
        int n4;
        this.index = BlockModelRotation.getIndex(n2, n3);
        Quaternion quaternion = Vector3f.YP.rotationDegrees(-n3);
        quaternion.mul(Vector3f.XP.rotationDegrees(-n2));
        OctahedralGroup octahedralGroup = OctahedralGroup.IDENTITY;
        for (n4 = 0; n4 < n3; n4 += 90) {
            octahedralGroup = octahedralGroup.compose(OctahedralGroup.ROT_90_Y_NEG);
        }
        for (n4 = 0; n4 < n2; n4 += 90) {
            octahedralGroup = octahedralGroup.compose(OctahedralGroup.ROT_90_X_NEG);
        }
        this.transformation = new Transformation(null, quaternion, null, null);
        this.actualRotation = octahedralGroup;
    }

    @Override
    public Transformation getRotation() {
        return this.transformation;
    }

    public static BlockModelRotation by(int n, int n2) {
        return BY_INDEX.get(BlockModelRotation.getIndex(Mth.positiveModulo(n, 360), Mth.positiveModulo(n2, 360)));
    }

    public OctahedralGroup actualRotation() {
        return this.actualRotation;
    }

    private static /* synthetic */ BlockModelRotation[] $values() {
        return new BlockModelRotation[]{X0_Y0, X0_Y90, X0_Y180, X0_Y270, X90_Y0, X90_Y90, X90_Y180, X90_Y270, X180_Y0, X180_Y90, X180_Y180, X180_Y270, X270_Y0, X270_Y90, X270_Y180, X270_Y270};
    }

    static {
        $VALUES = BlockModelRotation.$values();
        BY_INDEX = Arrays.stream(BlockModelRotation.values()).collect(Collectors.toMap(blockModelRotation -> blockModelRotation.index, blockModelRotation -> blockModelRotation));
    }
}

