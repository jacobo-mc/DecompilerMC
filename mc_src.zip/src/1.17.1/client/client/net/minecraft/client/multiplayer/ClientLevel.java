/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableMap
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap
 *  javax.annotation.Nullable
 */
package net.minecraft.client.multiplayer;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.function.BiConsumer;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;
import javax.annotation.Nullable;
import net.minecraft.CrashReport;
import net.minecraft.CrashReportCategory;
import net.minecraft.CrashReportDetail;
import net.minecraft.ReportedException;
import net.minecraft.Util;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.color.block.BlockTintCache;
import net.minecraft.client.multiplayer.ClientChunkCache;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.particle.FireworkParticles;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.BiomeColors;
import net.minecraft.client.renderer.DimensionSpecialEffects;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.resources.sounds.EntityBoundSoundInstance;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Cursor3D;
import net.minecraft.core.DefaultedRegistry;
import net.minecraft.core.Direction;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.Vec3i;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.network.protocol.Packet;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.Tag;
import net.minecraft.tags.TagContainer;
import net.minecraft.util.CubicSampler;
import net.minecraft.util.Mth;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.ColorResolver;
import net.minecraft.world.level.EmptyTickList;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.TickList;
import net.minecraft.world.level.biome.AmbientParticleSettings;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.border.WorldBorder;
import net.minecraft.world.level.chunk.ChunkSource;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.entity.EntityTickList;
import net.minecraft.world.level.entity.LevelCallback;
import net.minecraft.world.level.entity.LevelEntityGetter;
import net.minecraft.world.level.entity.TransientEntitySectionManager;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.lighting.LevelLightEngine;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;
import net.minecraft.world.level.storage.LevelData;
import net.minecraft.world.level.storage.WritableLevelData;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.scores.Scoreboard;

public class ClientLevel
extends Level {
    private static final double FLUID_PARTICLE_SPAWN_OFFSET = 0.05;
    final EntityTickList tickingEntities = new EntityTickList();
    private final TransientEntitySectionManager<Entity> entityStorage = new TransientEntitySectionManager<Entity>(Entity.class, new EntityCallbacks());
    private final ClientPacketListener connection;
    private final LevelRenderer levelRenderer;
    private final ClientLevelData clientLevelData;
    private final DimensionSpecialEffects effects;
    private final Minecraft minecraft = Minecraft.getInstance();
    final List<AbstractClientPlayer> players = Lists.newArrayList();
    private Scoreboard scoreboard = new Scoreboard();
    private final Map<String, MapItemSavedData> mapData = Maps.newHashMap();
    private static final long CLOUD_COLOR = 0xFFFFFFL;
    private int skyFlashTime;
    private final Object2ObjectArrayMap<ColorResolver, BlockTintCache> tintCaches = Util.make(new Object2ObjectArrayMap(3), object2ObjectArrayMap -> {
        object2ObjectArrayMap.put((Object)BiomeColors.GRASS_COLOR_RESOLVER, (Object)new BlockTintCache());
        object2ObjectArrayMap.put((Object)BiomeColors.FOLIAGE_COLOR_RESOLVER, (Object)new BlockTintCache());
        object2ObjectArrayMap.put((Object)BiomeColors.WATER_COLOR_RESOLVER, (Object)new BlockTintCache());
    });
    private final ClientChunkCache chunkSource;

    public ClientLevel(ClientPacketListener clientPacketListener, ClientLevelData clientLevelData, ResourceKey<Level> resourceKey, DimensionType dimensionType, int n, Supplier<ProfilerFiller> supplier, LevelRenderer levelRenderer, boolean bl, long l) {
        super(clientLevelData, resourceKey, dimensionType, supplier, true, bl, l);
        this.connection = clientPacketListener;
        this.chunkSource = new ClientChunkCache(this, n);
        this.clientLevelData = clientLevelData;
        this.levelRenderer = levelRenderer;
        this.effects = DimensionSpecialEffects.forType(dimensionType);
        this.setDefaultSpawnPos(new BlockPos(8, 64, 8), 0.0f);
        this.updateSkyBrightness();
        this.prepareWeather();
    }

    public DimensionSpecialEffects effects() {
        return this.effects;
    }

    public void tick(BooleanSupplier booleanSupplier) {
        this.getWorldBorder().tick();
        this.tickTime();
        this.getProfiler().push("blocks");
        this.chunkSource.tick(booleanSupplier);
        this.getProfiler().pop();
    }

    private void tickTime() {
        this.setGameTime(this.levelData.getGameTime() + 1L);
        if (this.levelData.getGameRules().getBoolean(GameRules.RULE_DAYLIGHT)) {
            this.setDayTime(this.levelData.getDayTime() + 1L);
        }
    }

    public void setGameTime(long l) {
        this.clientLevelData.setGameTime(l);
    }

    public void setDayTime(long l) {
        if (l < 0L) {
            l = -l;
            this.getGameRules().getRule(GameRules.RULE_DAYLIGHT).set(false, null);
        } else {
            this.getGameRules().getRule(GameRules.RULE_DAYLIGHT).set(true, null);
        }
        this.clientLevelData.setDayTime(l);
    }

    public Iterable<Entity> entitiesForRendering() {
        return this.getEntities().getAll();
    }

    public void tickEntities() {
        ProfilerFiller profilerFiller = this.getProfiler();
        profilerFiller.push("entities");
        this.tickingEntities.forEach(entity -> {
            if (entity.isRemoved() || entity.isPassenger()) {
                return;
            }
            this.guardEntityTick(this::tickNonPassenger, entity);
        });
        profilerFiller.pop();
        this.tickBlockEntities();
    }

    public void tickNonPassenger(Entity entity) {
        entity.setOldPosAndRot();
        ++entity.tickCount;
        this.getProfiler().push(() -> Registry.ENTITY_TYPE.getKey(entity.getType()).toString());
        entity.tick();
        this.getProfiler().pop();
        for (Entity entity2 : entity.getPassengers()) {
            this.tickPassenger(entity, entity2);
        }
    }

    private void tickPassenger(Entity entity, Entity entity2) {
        if (entity2.isRemoved() || entity2.getVehicle() != entity) {
            entity2.stopRiding();
            return;
        }
        if (!(entity2 instanceof Player) && !this.tickingEntities.contains(entity2)) {
            return;
        }
        entity2.setOldPosAndRot();
        ++entity2.tickCount;
        entity2.rideTick();
        for (Entity entity3 : entity2.getPassengers()) {
            this.tickPassenger(entity2, entity3);
        }
    }

    public void unload(LevelChunk levelChunk) {
        levelChunk.invalidateAllBlockEntities();
        this.chunkSource.getLightEngine().enableLightSources(levelChunk.getPos(), false);
        this.entityStorage.stopTicking(levelChunk.getPos());
    }

    public void onChunkLoaded(ChunkPos chunkPos) {
        this.tintCaches.forEach((colorResolver, blockTintCache) -> blockTintCache.invalidateForChunk(chunkPos.x, chunkPos.z));
        this.entityStorage.startTicking(chunkPos);
    }

    public void clearTintCaches() {
        this.tintCaches.forEach((colorResolver, blockTintCache) -> blockTintCache.invalidateAll());
    }

    @Override
    public boolean hasChunk(int n, int n2) {
        return true;
    }

    public int getEntityCount() {
        return this.entityStorage.count();
    }

    public void addPlayer(int n, AbstractClientPlayer abstractClientPlayer) {
        this.addEntity(n, abstractClientPlayer);
    }

    public void putNonPlayerEntity(int n, Entity entity) {
        this.addEntity(n, entity);
    }

    private void addEntity(int n, Entity entity) {
        this.removeEntity(n, Entity.RemovalReason.DISCARDED);
        this.entityStorage.addEntity(entity);
    }

    public void removeEntity(int n, Entity.RemovalReason removalReason) {
        Entity entity = this.getEntities().get(n);
        if (entity != null) {
            entity.setRemoved(removalReason);
            entity.onClientRemoval();
        }
    }

    @Nullable
    @Override
    public Entity getEntity(int n) {
        return this.getEntities().get(n);
    }

    public void setKnownState(BlockPos blockPos, BlockState blockState) {
        this.setBlock(blockPos, blockState, 19);
    }

    @Override
    public void disconnect() {
        this.connection.getConnection().disconnect(new TranslatableComponent("multiplayer.status.quitting"));
    }

    public void animateTick(int n, int n2, int n3) {
        int n4 = 32;
        Random random = new Random();
        MarkerParticleStatus markerParticleStatus = this.getMarkerParticleStatus();
        BlockPos.MutableBlockPos mutableBlockPos = new BlockPos.MutableBlockPos();
        for (int i = 0; i < 667; ++i) {
            this.doAnimateTick(n, n2, n3, 16, random, markerParticleStatus, mutableBlockPos);
            this.doAnimateTick(n, n2, n3, 32, random, markerParticleStatus, mutableBlockPos);
        }
    }

    @Nullable
    private MarkerParticleStatus getMarkerParticleStatus() {
        if (this.minecraft.gameMode.getPlayerMode() == GameType.CREATIVE) {
            ItemStack itemStack = this.minecraft.player.getMainHandItem();
            if (itemStack.getItem() == Items.BARRIER) {
                return MarkerParticleStatus.BARRIER;
            }
            if (itemStack.getItem() == Items.LIGHT) {
                return MarkerParticleStatus.LIGHT;
            }
        }
        return null;
    }

    public void doAnimateTick(int n, int n2, int n3, int n4, Random random, @Nullable MarkerParticleStatus markerParticleStatus, BlockPos.MutableBlockPos mutableBlockPos) {
        int n5 = n + this.random.nextInt(n4) - this.random.nextInt(n4);
        int n6 = n2 + this.random.nextInt(n4) - this.random.nextInt(n4);
        int n7 = n3 + this.random.nextInt(n4) - this.random.nextInt(n4);
        mutableBlockPos.set(n5, n6, n7);
        BlockState blockState = this.getBlockState(mutableBlockPos);
        blockState.getBlock().animateTick(blockState, this, mutableBlockPos, random);
        FluidState fluidState = this.getFluidState(mutableBlockPos);
        if (!fluidState.isEmpty()) {
            fluidState.animateTick(this, mutableBlockPos, random);
            ParticleOptions particleOptions = fluidState.getDripParticle();
            if (particleOptions != null && this.random.nextInt(10) == 0) {
                boolean bl = blockState.isFaceSturdy(this, mutableBlockPos, Direction.DOWN);
                Vec3i vec3i = mutableBlockPos.below();
                this.trySpawnDripParticles((BlockPos)vec3i, this.getBlockState((BlockPos)vec3i), particleOptions, bl);
            }
        }
        if (markerParticleStatus != null && blockState.getBlock() == markerParticleStatus.block) {
            this.addParticle(markerParticleStatus.particle, (double)n5 + 0.5, (double)n6 + 0.5, (double)n7 + 0.5, 0.0, 0.0, 0.0);
        }
        if (!blockState.isCollisionShapeFullBlock(this, mutableBlockPos)) {
            this.getBiome(mutableBlockPos).getAmbientParticle().ifPresent(ambientParticleSettings -> {
                if (ambientParticleSettings.canSpawn(this.random)) {
                    this.addParticle(ambientParticleSettings.getOptions(), (double)mutableBlockPos.getX() + this.random.nextDouble(), (double)mutableBlockPos.getY() + this.random.nextDouble(), (double)mutableBlockPos.getZ() + this.random.nextDouble(), 0.0, 0.0, 0.0);
                }
            });
        }
    }

    private void trySpawnDripParticles(BlockPos blockPos, BlockState blockState, ParticleOptions particleOptions, boolean bl) {
        if (!blockState.getFluidState().isEmpty()) {
            return;
        }
        VoxelShape voxelShape = blockState.getCollisionShape(this, blockPos);
        double d = voxelShape.max(Direction.Axis.Y);
        if (d < 1.0) {
            if (bl) {
                this.spawnFluidParticle(blockPos.getX(), blockPos.getX() + 1, blockPos.getZ(), blockPos.getZ() + 1, (double)(blockPos.getY() + 1) - 0.05, particleOptions);
            }
        } else if (!blockState.is(BlockTags.IMPERMEABLE)) {
            double d2 = voxelShape.min(Direction.Axis.Y);
            if (d2 > 0.0) {
                this.spawnParticle(blockPos, particleOptions, voxelShape, (double)blockPos.getY() + d2 - 0.05);
            } else {
                BlockPos blockPos2 = blockPos.below();
                BlockState blockState2 = this.getBlockState(blockPos2);
                VoxelShape voxelShape2 = blockState2.getCollisionShape(this, blockPos2);
                double d3 = voxelShape2.max(Direction.Axis.Y);
                if (d3 < 1.0 && blockState2.getFluidState().isEmpty()) {
                    this.spawnParticle(blockPos, particleOptions, voxelShape, (double)blockPos.getY() - 0.05);
                }
            }
        }
    }

    private void spawnParticle(BlockPos blockPos, ParticleOptions particleOptions, VoxelShape voxelShape, double d) {
        this.spawnFluidParticle((double)blockPos.getX() + voxelShape.min(Direction.Axis.X), (double)blockPos.getX() + voxelShape.max(Direction.Axis.X), (double)blockPos.getZ() + voxelShape.min(Direction.Axis.Z), (double)blockPos.getZ() + voxelShape.max(Direction.Axis.Z), d, particleOptions);
    }

    private void spawnFluidParticle(double d, double d2, double d3, double d4, double d5, ParticleOptions particleOptions) {
        this.addParticle(particleOptions, Mth.lerp(this.random.nextDouble(), d, d2), d5, Mth.lerp(this.random.nextDouble(), d3, d4), 0.0, 0.0, 0.0);
    }

    @Override
    public CrashReportCategory fillReportDetails(CrashReport crashReport) {
        CrashReportCategory crashReportCategory = super.fillReportDetails(crashReport);
        crashReportCategory.setDetail("Server brand", () -> this.minecraft.player.getServerBrand());
        crashReportCategory.setDetail("Server type", () -> this.minecraft.getSingleplayerServer() == null ? "Non-integrated multiplayer server" : "Integrated singleplayer server");
        return crashReportCategory;
    }

    @Override
    public void playSound(@Nullable Player player, double d, double d2, double d3, SoundEvent soundEvent, SoundSource soundSource, float f, float f2) {
        if (player == this.minecraft.player) {
            this.playLocalSound(d, d2, d3, soundEvent, soundSource, f, f2, false);
        }
    }

    @Override
    public void playSound(@Nullable Player player, Entity entity, SoundEvent soundEvent, SoundSource soundSource, float f, float f2) {
        if (player == this.minecraft.player) {
            this.minecraft.getSoundManager().play(new EntityBoundSoundInstance(soundEvent, soundSource, f, f2, entity));
        }
    }

    public void playLocalSound(BlockPos blockPos, SoundEvent soundEvent, SoundSource soundSource, float f, float f2, boolean bl) {
        this.playLocalSound((double)blockPos.getX() + 0.5, (double)blockPos.getY() + 0.5, (double)blockPos.getZ() + 0.5, soundEvent, soundSource, f, f2, bl);
    }

    @Override
    public void playLocalSound(double d, double d2, double d3, SoundEvent soundEvent, SoundSource soundSource, float f, float f2, boolean bl) {
        double d4 = this.minecraft.gameRenderer.getMainCamera().getPosition().distanceToSqr(d, d2, d3);
        SimpleSoundInstance simpleSoundInstance = new SimpleSoundInstance(soundEvent, soundSource, f, f2, d, d2, d3);
        if (bl && d4 > 100.0) {
            double d5 = Math.sqrt(d4) / 40.0;
            this.minecraft.getSoundManager().playDelayed(simpleSoundInstance, (int)(d5 * 20.0));
        } else {
            this.minecraft.getSoundManager().play(simpleSoundInstance);
        }
    }

    @Override
    public void createFireworks(double d, double d2, double d3, double d4, double d5, double d6, @Nullable CompoundTag compoundTag) {
        this.minecraft.particleEngine.add(new FireworkParticles.Starter(this, d, d2, d3, d4, d5, d6, this.minecraft.particleEngine, compoundTag));
    }

    @Override
    public void sendPacketToServer(Packet<?> packet) {
        this.connection.send(packet);
    }

    @Override
    public RecipeManager getRecipeManager() {
        return this.connection.getRecipeManager();
    }

    public void setScoreboard(Scoreboard scoreboard) {
        this.scoreboard = scoreboard;
    }

    @Override
    public TickList<Block> getBlockTicks() {
        return EmptyTickList.empty();
    }

    @Override
    public TickList<Fluid> getLiquidTicks() {
        return EmptyTickList.empty();
    }

    @Override
    public ClientChunkCache getChunkSource() {
        return this.chunkSource;
    }

    @Nullable
    @Override
    public MapItemSavedData getMapData(String string) {
        return this.mapData.get(string);
    }

    @Override
    public void setMapData(String string, MapItemSavedData mapItemSavedData) {
        this.mapData.put(string, mapItemSavedData);
    }

    @Override
    public int getFreeMapId() {
        return 0;
    }

    @Override
    public Scoreboard getScoreboard() {
        return this.scoreboard;
    }

    @Override
    public TagContainer getTagManager() {
        return this.connection.getTags();
    }

    @Override
    public RegistryAccess registryAccess() {
        return this.connection.registryAccess();
    }

    @Override
    public void sendBlockUpdated(BlockPos blockPos, BlockState blockState, BlockState blockState2, int n) {
        this.levelRenderer.blockChanged(this, blockPos, blockState, blockState2, n);
    }

    @Override
    public void setBlocksDirty(BlockPos blockPos, BlockState blockState, BlockState blockState2) {
        this.levelRenderer.setBlockDirty(blockPos, blockState, blockState2);
    }

    public void setSectionDirtyWithNeighbors(int n, int n2, int n3) {
        this.levelRenderer.setSectionDirtyWithNeighbors(n, n2, n3);
    }

    @Override
    public void destroyBlockProgress(int n, BlockPos blockPos, int n2) {
        this.levelRenderer.destroyBlockProgress(n, blockPos, n2);
    }

    @Override
    public void globalLevelEvent(int n, BlockPos blockPos, int n2) {
        this.levelRenderer.globalLevelEvent(n, blockPos, n2);
    }

    @Override
    public void levelEvent(@Nullable Player player, int n, BlockPos blockPos, int n2) {
        try {
            this.levelRenderer.levelEvent(player, n, blockPos, n2);
        }
        catch (Throwable throwable) {
            CrashReport crashReport = CrashReport.forThrowable(throwable, "Playing level event");
            CrashReportCategory crashReportCategory = crashReport.addCategory("Level event being played");
            crashReportCategory.setDetail("Block coordinates", CrashReportCategory.formatLocation(this, blockPos));
            crashReportCategory.setDetail("Event source", player);
            crashReportCategory.setDetail("Event type", n);
            crashReportCategory.setDetail("Event data", n2);
            throw new ReportedException(crashReport);
        }
    }

    @Override
    public void addParticle(ParticleOptions particleOptions, double d, double d2, double d3, double d4, double d5, double d6) {
        this.levelRenderer.addParticle(particleOptions, particleOptions.getType().getOverrideLimiter(), d, d2, d3, d4, d5, d6);
    }

    @Override
    public void addParticle(ParticleOptions particleOptions, boolean bl, double d, double d2, double d3, double d4, double d5, double d6) {
        this.levelRenderer.addParticle(particleOptions, particleOptions.getType().getOverrideLimiter() || bl, d, d2, d3, d4, d5, d6);
    }

    @Override
    public void addAlwaysVisibleParticle(ParticleOptions particleOptions, double d, double d2, double d3, double d4, double d5, double d6) {
        this.levelRenderer.addParticle(particleOptions, false, true, d, d2, d3, d4, d5, d6);
    }

    @Override
    public void addAlwaysVisibleParticle(ParticleOptions particleOptions, boolean bl, double d, double d2, double d3, double d4, double d5, double d6) {
        this.levelRenderer.addParticle(particleOptions, particleOptions.getType().getOverrideLimiter() || bl, true, d, d2, d3, d4, d5, d6);
    }

    public List<AbstractClientPlayer> players() {
        return this.players;
    }

    @Override
    public Biome getUncachedNoiseBiome(int n, int n2, int n3) {
        return this.registryAccess().registryOrThrow(Registry.BIOME_REGISTRY).getOrThrow(Biomes.PLAINS);
    }

    public float getSkyDarken(float f) {
        float f2 = this.getTimeOfDay(f);
        float f3 = 1.0f - (Mth.cos(f2 * 6.2831855f) * 2.0f + 0.2f);
        f3 = Mth.clamp(f3, 0.0f, 1.0f);
        f3 = 1.0f - f3;
        f3 = (float)((double)f3 * (1.0 - (double)(this.getRainLevel(f) * 5.0f) / 16.0));
        f3 = (float)((double)f3 * (1.0 - (double)(this.getThunderLevel(f) * 5.0f) / 16.0));
        return f3 * 0.8f + 0.2f;
    }

    public Vec3 getSkyColor(Vec3 vec3, float f) {
        float f2;
        float f3;
        float f4 = this.getTimeOfDay(f);
        Vec3 vec32 = vec3.subtract(2.0, 2.0, 2.0).scale(0.25);
        BiomeManager biomeManager = this.getBiomeManager();
        Vec3 vec33 = CubicSampler.gaussianSampleVec3(vec32, (n, n2, n3) -> Vec3.fromRGB24(biomeManager.getNoiseBiomeAtQuart(n, n2, n3).getSkyColor()));
        float f5 = Mth.cos(f4 * 6.2831855f) * 2.0f + 0.5f;
        f5 = Mth.clamp(f5, 0.0f, 1.0f);
        float f6 = (float)vec33.x * f5;
        float f7 = (float)vec33.y * f5;
        float f8 = (float)vec33.z * f5;
        float f9 = this.getRainLevel(f);
        if (f9 > 0.0f) {
            f2 = (f6 * 0.3f + f7 * 0.59f + f8 * 0.11f) * 0.6f;
            f3 = 1.0f - f9 * 0.75f;
            f6 = f6 * f3 + f2 * (1.0f - f3);
            f7 = f7 * f3 + f2 * (1.0f - f3);
            f8 = f8 * f3 + f2 * (1.0f - f3);
        }
        if ((f2 = this.getThunderLevel(f)) > 0.0f) {
            f3 = (f6 * 0.3f + f7 * 0.59f + f8 * 0.11f) * 0.2f;
            float f10 = 1.0f - f2 * 0.75f;
            f6 = f6 * f10 + f3 * (1.0f - f10);
            f7 = f7 * f10 + f3 * (1.0f - f10);
            f8 = f8 * f10 + f3 * (1.0f - f10);
        }
        if (this.skyFlashTime > 0) {
            f3 = (float)this.skyFlashTime - f;
            if (f3 > 1.0f) {
                f3 = 1.0f;
            }
            f6 = f6 * (1.0f - (f3 *= 0.45f)) + 0.8f * f3;
            f7 = f7 * (1.0f - f3) + 0.8f * f3;
            f8 = f8 * (1.0f - f3) + 1.0f * f3;
        }
        return new Vec3(f6, f7, f8);
    }

    public Vec3 getCloudColor(float f) {
        float f2;
        float f3;
        float f4 = this.getTimeOfDay(f);
        float f5 = Mth.cos(f4 * 6.2831855f) * 2.0f + 0.5f;
        f5 = Mth.clamp(f5, 0.0f, 1.0f);
        float f6 = 1.0f;
        float f7 = 1.0f;
        float f8 = 1.0f;
        float f9 = this.getRainLevel(f);
        if (f9 > 0.0f) {
            f2 = (f6 * 0.3f + f7 * 0.59f + f8 * 0.11f) * 0.6f;
            f3 = 1.0f - f9 * 0.95f;
            f6 = f6 * f3 + f2 * (1.0f - f3);
            f7 = f7 * f3 + f2 * (1.0f - f3);
            f8 = f8 * f3 + f2 * (1.0f - f3);
        }
        f6 *= f5 * 0.9f + 0.1f;
        f7 *= f5 * 0.9f + 0.1f;
        f8 *= f5 * 0.85f + 0.15f;
        f2 = this.getThunderLevel(f);
        if (f2 > 0.0f) {
            f3 = (f6 * 0.3f + f7 * 0.59f + f8 * 0.11f) * 0.2f;
            float f10 = 1.0f - f2 * 0.95f;
            f6 = f6 * f10 + f3 * (1.0f - f10);
            f7 = f7 * f10 + f3 * (1.0f - f10);
            f8 = f8 * f10 + f3 * (1.0f - f10);
        }
        return new Vec3(f6, f7, f8);
    }

    public float getStarBrightness(float f) {
        float f2 = this.getTimeOfDay(f);
        float f3 = 1.0f - (Mth.cos(f2 * 6.2831855f) * 2.0f + 0.25f);
        f3 = Mth.clamp(f3, 0.0f, 1.0f);
        return f3 * f3 * 0.5f;
    }

    public int getSkyFlashTime() {
        return this.skyFlashTime;
    }

    @Override
    public void setSkyFlashTime(int n) {
        this.skyFlashTime = n;
    }

    @Override
    public float getShade(Direction direction, boolean bl) {
        boolean bl2 = this.effects().constantAmbientLight();
        if (!bl) {
            return bl2 ? 0.9f : 1.0f;
        }
        switch (direction) {
            case DOWN: {
                return bl2 ? 0.9f : 0.5f;
            }
            case UP: {
                return bl2 ? 0.9f : 1.0f;
            }
            case NORTH: 
            case SOUTH: {
                return 0.8f;
            }
            case WEST: 
            case EAST: {
                return 0.6f;
            }
        }
        return 1.0f;
    }

    @Override
    public int getBlockTint(BlockPos blockPos, ColorResolver colorResolver) {
        BlockTintCache blockTintCache = (BlockTintCache)this.tintCaches.get((Object)colorResolver);
        return blockTintCache.getColor(blockPos, () -> this.calculateBlockTint(blockPos, colorResolver));
    }

    public int calculateBlockTint(BlockPos blockPos, ColorResolver colorResolver) {
        int n = Minecraft.getInstance().options.biomeBlendRadius;
        if (n == 0) {
            return colorResolver.getColor(this.getBiome(blockPos), blockPos.getX(), blockPos.getZ());
        }
        int n2 = (n * 2 + 1) * (n * 2 + 1);
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        Cursor3D cursor3D = new Cursor3D(blockPos.getX() - n, blockPos.getY(), blockPos.getZ() - n, blockPos.getX() + n, blockPos.getY(), blockPos.getZ() + n);
        BlockPos.MutableBlockPos mutableBlockPos = new BlockPos.MutableBlockPos();
        while (cursor3D.advance()) {
            mutableBlockPos.set(cursor3D.nextX(), cursor3D.nextY(), cursor3D.nextZ());
            int n6 = colorResolver.getColor(this.getBiome(mutableBlockPos), mutableBlockPos.getX(), mutableBlockPos.getZ());
            n3 += (n6 & 0xFF0000) >> 16;
            n4 += (n6 & 0xFF00) >> 8;
            n5 += n6 & 0xFF;
        }
        return (n3 / n2 & 0xFF) << 16 | (n4 / n2 & 0xFF) << 8 | n5 / n2 & 0xFF;
    }

    public BlockPos getSharedSpawnPos() {
        BlockPos blockPos = new BlockPos(this.levelData.getXSpawn(), this.levelData.getYSpawn(), this.levelData.getZSpawn());
        if (!this.getWorldBorder().isWithinBounds(blockPos)) {
            blockPos = this.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, new BlockPos(this.getWorldBorder().getCenterX(), 0.0, this.getWorldBorder().getCenterZ()));
        }
        return blockPos;
    }

    public float getSharedSpawnAngle() {
        return this.levelData.getSpawnAngle();
    }

    public void setDefaultSpawnPos(BlockPos blockPos, float f) {
        this.levelData.setSpawn(blockPos, f);
    }

    public String toString() {
        return "ClientLevel";
    }

    @Override
    public ClientLevelData getLevelData() {
        return this.clientLevelData;
    }

    @Override
    public void gameEvent(@Nullable Entity entity, GameEvent gameEvent, BlockPos blockPos) {
    }

    protected Map<String, MapItemSavedData> getAllMapData() {
        return ImmutableMap.copyOf(this.mapData);
    }

    protected void addMapData(Map<String, MapItemSavedData> map) {
        this.mapData.putAll(map);
    }

    @Override
    protected LevelEntityGetter<Entity> getEntities() {
        return this.entityStorage.getEntityGetter();
    }

    @Override
    public String gatherChunkSourceStats() {
        return "Chunks[C] W: " + this.chunkSource.gatherStats() + " E: " + this.entityStorage.gatherStats();
    }

    @Override
    public void addDestroyBlockEffect(BlockPos blockPos, BlockState blockState) {
        this.minecraft.particleEngine.destroy(blockPos, blockState);
    }

    @Override
    public /* synthetic */ LevelData getLevelData() {
        return this.getLevelData();
    }

    @Override
    public /* synthetic */ ChunkSource getChunkSource() {
        return this.getChunkSource();
    }

    final class EntityCallbacks
    implements LevelCallback<Entity> {
        EntityCallbacks() {
        }

        @Override
        public void onCreated(Entity entity) {
        }

        @Override
        public void onDestroyed(Entity entity) {
        }

        @Override
        public void onTickingStart(Entity entity) {
            ClientLevel.this.tickingEntities.add(entity);
        }

        @Override
        public void onTickingEnd(Entity entity) {
            ClientLevel.this.tickingEntities.remove(entity);
        }

        @Override
        public void onTrackingStart(Entity entity) {
            if (entity instanceof AbstractClientPlayer) {
                ClientLevel.this.players.add((AbstractClientPlayer)entity);
            }
        }

        @Override
        public void onTrackingEnd(Entity entity) {
            entity.unRide();
            ClientLevel.this.players.remove(entity);
        }

        @Override
        public /* synthetic */ void onTrackingEnd(Object object) {
            this.onTrackingEnd((Entity)object);
        }

        @Override
        public /* synthetic */ void onTrackingStart(Object object) {
            this.onTrackingStart((Entity)object);
        }

        @Override
        public /* synthetic */ void onTickingEnd(Object object) {
            this.onTickingEnd((Entity)object);
        }

        @Override
        public /* synthetic */ void onTickingStart(Object object) {
            this.onTickingStart((Entity)object);
        }

        @Override
        public /* synthetic */ void onDestroyed(Object object) {
            this.onDestroyed((Entity)object);
        }

        @Override
        public /* synthetic */ void onCreated(Object object) {
            this.onCreated((Entity)object);
        }
    }

    public static class ClientLevelData
    implements WritableLevelData {
        private final boolean hardcore;
        private final GameRules gameRules;
        private final boolean isFlat;
        private int xSpawn;
        private int ySpawn;
        private int zSpawn;
        private float spawnAngle;
        private long gameTime;
        private long dayTime;
        private boolean raining;
        private Difficulty difficulty;
        private boolean difficultyLocked;

        public ClientLevelData(Difficulty difficulty, boolean bl, boolean bl2) {
            this.difficulty = difficulty;
            this.hardcore = bl;
            this.isFlat = bl2;
            this.gameRules = new GameRules();
        }

        @Override
        public int getXSpawn() {
            return this.xSpawn;
        }

        @Override
        public int getYSpawn() {
            return this.ySpawn;
        }

        @Override
        public int getZSpawn() {
            return this.zSpawn;
        }

        @Override
        public float getSpawnAngle() {
            return this.spawnAngle;
        }

        @Override
        public long getGameTime() {
            return this.gameTime;
        }

        @Override
        public long getDayTime() {
            return this.dayTime;
        }

        @Override
        public void setXSpawn(int n) {
            this.xSpawn = n;
        }

        @Override
        public void setYSpawn(int n) {
            this.ySpawn = n;
        }

        @Override
        public void setZSpawn(int n) {
            this.zSpawn = n;
        }

        @Override
        public void setSpawnAngle(float f) {
            this.spawnAngle = f;
        }

        public void setGameTime(long l) {
            this.gameTime = l;
        }

        public void setDayTime(long l) {
            this.dayTime = l;
        }

        @Override
        public void setSpawn(BlockPos blockPos, float f) {
            this.xSpawn = blockPos.getX();
            this.ySpawn = blockPos.getY();
            this.zSpawn = blockPos.getZ();
            this.spawnAngle = f;
        }

        @Override
        public boolean isThundering() {
            return false;
        }

        @Override
        public boolean isRaining() {
            return this.raining;
        }

        @Override
        public void setRaining(boolean bl) {
            this.raining = bl;
        }

        @Override
        public boolean isHardcore() {
            return this.hardcore;
        }

        @Override
        public GameRules getGameRules() {
            return this.gameRules;
        }

        @Override
        public Difficulty getDifficulty() {
            return this.difficulty;
        }

        @Override
        public boolean isDifficultyLocked() {
            return this.difficultyLocked;
        }

        @Override
        public void fillCrashReportCategory(CrashReportCategory crashReportCategory, LevelHeightAccessor levelHeightAccessor) {
            WritableLevelData.super.fillCrashReportCategory(crashReportCategory, levelHeightAccessor);
        }

        public void setDifficulty(Difficulty difficulty) {
            this.difficulty = difficulty;
        }

        public void setDifficultyLocked(boolean bl) {
            this.difficultyLocked = bl;
        }

        public double getHorizonHeight(LevelHeightAccessor levelHeightAccessor) {
            if (this.isFlat) {
                return levelHeightAccessor.getMinBuildHeight();
            }
            return 63.0;
        }

        public double getClearColorScale() {
            if (this.isFlat) {
                return 1.0;
            }
            return 0.03125;
        }
    }

    static final class MarkerParticleStatus
    extends Enum<MarkerParticleStatus> {
        public static final /* enum */ MarkerParticleStatus BARRIER = new MarkerParticleStatus(Blocks.BARRIER, ParticleTypes.BARRIER);
        public static final /* enum */ MarkerParticleStatus LIGHT = new MarkerParticleStatus(Blocks.LIGHT, ParticleTypes.LIGHT);
        final Block block;
        final ParticleOptions particle;
        private static final /* synthetic */ MarkerParticleStatus[] $VALUES;

        public static MarkerParticleStatus[] values() {
            return (MarkerParticleStatus[])$VALUES.clone();
        }

        public static MarkerParticleStatus valueOf(String string) {
            return Enum.valueOf(MarkerParticleStatus.class, string);
        }

        private MarkerParticleStatus(Block block, ParticleOptions particleOptions) {
            this.block = block;
            this.particle = particleOptions;
        }

        private static /* synthetic */ MarkerParticleStatus[] $values() {
            return new MarkerParticleStatus[]{BARRIER, LIGHT};
        }

        static {
            $VALUES = MarkerParticleStatus.$values();
        }
    }

}

