/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.color.item;

import net.minecraft.world.item.ItemStack;

public interface ItemColor {
    public int getColor(ItemStack var1, int var2);
}

