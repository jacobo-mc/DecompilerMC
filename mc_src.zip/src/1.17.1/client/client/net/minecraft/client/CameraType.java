/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client;

public final class CameraType
extends Enum<CameraType> {
    public static final /* enum */ CameraType FIRST_PERSON = new CameraType(true, false);
    public static final /* enum */ CameraType THIRD_PERSON_BACK = new CameraType(false, false);
    public static final /* enum */ CameraType THIRD_PERSON_FRONT = new CameraType(false, true);
    private static final CameraType[] VALUES;
    private final boolean firstPerson;
    private final boolean mirrored;
    private static final /* synthetic */ CameraType[] $VALUES;

    public static CameraType[] values() {
        return (CameraType[])$VALUES.clone();
    }

    public static CameraType valueOf(String string) {
        return Enum.valueOf(CameraType.class, string);
    }

    private CameraType(boolean bl, boolean bl2) {
        this.firstPerson = bl;
        this.mirrored = bl2;
    }

    public boolean isFirstPerson() {
        return this.firstPerson;
    }

    public boolean isMirrored() {
        return this.mirrored;
    }

    public CameraType cycle() {
        return VALUES[(this.ordinal() + 1) % VALUES.length];
    }

    private static /* synthetic */ CameraType[] $values() {
        return new CameraType[]{FIRST_PERSON, THIRD_PERSON_BACK, THIRD_PERSON_FRONT};
    }

    static {
        $VALUES = CameraType.$values();
        VALUES = CameraType.values();
    }
}

