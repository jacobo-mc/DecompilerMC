/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.gui.screens.advancements;

public final class AdvancementWidgetType
extends Enum<AdvancementWidgetType> {
    public static final /* enum */ AdvancementWidgetType OBTAINED = new AdvancementWidgetType(0);
    public static final /* enum */ AdvancementWidgetType UNOBTAINED = new AdvancementWidgetType(1);
    private final int y;
    private static final /* synthetic */ AdvancementWidgetType[] $VALUES;

    public static AdvancementWidgetType[] values() {
        return (AdvancementWidgetType[])$VALUES.clone();
    }

    public static AdvancementWidgetType valueOf(String string) {
        return Enum.valueOf(AdvancementWidgetType.class, string);
    }

    private AdvancementWidgetType(int n2) {
        this.y = n2;
    }

    public int getIndex() {
        return this.y;
    }

    private static /* synthetic */ AdvancementWidgetType[] $values() {
        return new AdvancementWidgetType[]{OBTAINED, UNOBTAINED};
    }

    static {
        $VALUES = AdvancementWidgetType.$values();
    }
}

