/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  javax.annotation.Nullable
 */
package net.minecraft.client.gui.screens.inventory;

import com.google.common.collect.Lists;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import java.util.List;
import java.util.function.Consumer;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Widget;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.MobEffectTextureManager;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundSetBeaconPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.BeaconMenu;
import net.minecraft.world.inventory.ContainerListener;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.entity.BeaconBlockEntity;

public class BeaconScreen
extends AbstractContainerScreen<BeaconMenu> {
    static final ResourceLocation BEACON_LOCATION = new ResourceLocation("textures/gui/container/beacon.png");
    private static final Component PRIMARY_EFFECT_LABEL = new TranslatableComponent("block.minecraft.beacon.primary");
    private static final Component SECONDARY_EFFECT_LABEL = new TranslatableComponent("block.minecraft.beacon.secondary");
    private final List<BeaconButton> beaconButtons = Lists.newArrayList();
    @Nullable
    MobEffect primary;
    @Nullable
    MobEffect secondary;

    public BeaconScreen(final BeaconMenu beaconMenu, Inventory inventory, Component component) {
        super(beaconMenu, inventory, component);
        this.imageWidth = 230;
        this.imageHeight = 219;
        beaconMenu.addSlotListener(new ContainerListener(){

            @Override
            public void slotChanged(AbstractContainerMenu abstractContainerMenu, int n, ItemStack itemStack) {
            }

            @Override
            public void dataChanged(AbstractContainerMenu abstractContainerMenu, int n, int n2) {
                BeaconScreen.this.primary = beaconMenu.getPrimaryEffect();
                BeaconScreen.this.secondary = beaconMenu.getSecondaryEffect();
            }
        });
    }

    private <T extends AbstractWidget> void addBeaconButton(T t) {
        this.addRenderableWidget(t);
        this.beaconButtons.add((BeaconButton)t);
    }

    @Override
    protected void init() {
        int n;
        int n2;
        BeaconPowerButton beaconPowerButton;
        int n3;
        int n4;
        MobEffect mobEffect;
        super.init();
        this.beaconButtons.clear();
        this.addBeaconButton(new BeaconConfirmButton(this.leftPos + 164, this.topPos + 107));
        this.addBeaconButton(new BeaconCancelButton(this.leftPos + 190, this.topPos + 107));
        for (n3 = 0; n3 <= 2; ++n3) {
            n4 = BeaconBlockEntity.BEACON_EFFECTS[n3].length;
            n2 = n4 * 22 + (n4 - 1) * 2;
            for (n = 0; n < n4; ++n) {
                mobEffect = BeaconBlockEntity.BEACON_EFFECTS[n3][n];
                beaconPowerButton = new BeaconPowerButton(this.leftPos + 76 + n * 24 - n2 / 2, this.topPos + 22 + n3 * 25, mobEffect, true, n3);
                beaconPowerButton.active = false;
                this.addBeaconButton(beaconPowerButton);
            }
        }
        n3 = 3;
        n4 = BeaconBlockEntity.BEACON_EFFECTS[3].length + 1;
        n2 = n4 * 22 + (n4 - 1) * 2;
        for (n = 0; n < n4 - 1; ++n) {
            mobEffect = BeaconBlockEntity.BEACON_EFFECTS[3][n];
            beaconPowerButton = new BeaconPowerButton(this.leftPos + 167 + n * 24 - n2 / 2, this.topPos + 47, mobEffect, false, 3);
            beaconPowerButton.active = false;
            this.addBeaconButton(beaconPowerButton);
        }
        BeaconUpgradePowerButton beaconUpgradePowerButton = new BeaconUpgradePowerButton(this.leftPos + 167 + (n4 - 1) * 24 - n2 / 2, this.topPos + 47, BeaconBlockEntity.BEACON_EFFECTS[0][0]);
        beaconUpgradePowerButton.visible = false;
        this.addBeaconButton(beaconUpgradePowerButton);
    }

    @Override
    public void containerTick() {
        super.containerTick();
        this.updateButtons();
    }

    void updateButtons() {
        int n = ((BeaconMenu)this.menu).getLevels();
        this.beaconButtons.forEach(beaconButton -> beaconButton.updateStatus(n));
    }

    @Override
    protected void renderLabels(PoseStack poseStack, int n, int n2) {
        BeaconScreen.drawCenteredString(poseStack, this.font, PRIMARY_EFFECT_LABEL, 62, 10, 14737632);
        BeaconScreen.drawCenteredString(poseStack, this.font, SECONDARY_EFFECT_LABEL, 169, 10, 14737632);
        for (BeaconButton beaconButton : this.beaconButtons) {
            if (!beaconButton.isShowingTooltip()) continue;
            beaconButton.renderToolTip(poseStack, n - this.leftPos, n2 - this.topPos);
            break;
        }
    }

    @Override
    protected void renderBg(PoseStack poseStack, float f, int n, int n2) {
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        RenderSystem.setShaderTexture(0, BEACON_LOCATION);
        int n3 = (this.width - this.imageWidth) / 2;
        int n4 = (this.height - this.imageHeight) / 2;
        this.blit(poseStack, n3, n4, 0, 0, this.imageWidth, this.imageHeight);
        this.itemRenderer.blitOffset = 100.0f;
        this.itemRenderer.renderAndDecorateItem(new ItemStack(Items.NETHERITE_INGOT), n3 + 20, n4 + 109);
        this.itemRenderer.renderAndDecorateItem(new ItemStack(Items.EMERALD), n3 + 41, n4 + 109);
        this.itemRenderer.renderAndDecorateItem(new ItemStack(Items.DIAMOND), n3 + 41 + 22, n4 + 109);
        this.itemRenderer.renderAndDecorateItem(new ItemStack(Items.GOLD_INGOT), n3 + 42 + 44, n4 + 109);
        this.itemRenderer.renderAndDecorateItem(new ItemStack(Items.IRON_INGOT), n3 + 42 + 66, n4 + 109);
        this.itemRenderer.blitOffset = 0.0f;
    }

    @Override
    public void render(PoseStack poseStack, int n, int n2, float f) {
        this.renderBackground(poseStack);
        super.render(poseStack, n, n2, f);
        this.renderTooltip(poseStack, n, n2);
    }

    static /* synthetic */ Minecraft access$200(BeaconScreen beaconScreen) {
        return beaconScreen.minecraft;
    }

    static /* synthetic */ Minecraft access$300(BeaconScreen beaconScreen) {
        return beaconScreen.minecraft;
    }

    static interface BeaconButton {
        public boolean isShowingTooltip();

        public void renderToolTip(PoseStack var1, int var2, int var3);

        public void updateStatus(int var1);
    }

    class BeaconConfirmButton
    extends BeaconSpriteScreenButton {
        public BeaconConfirmButton(int n, int n2) {
            super(n, n2, 90, 220, CommonComponents.GUI_DONE);
        }

        @Override
        public void onPress() {
            BeaconScreen.this.minecraft.getConnection().send(new ServerboundSetBeaconPacket(MobEffect.getId(BeaconScreen.this.primary), MobEffect.getId(BeaconScreen.this.secondary)));
            BeaconScreen.access$200((BeaconScreen)BeaconScreen.this).player.closeContainer();
        }

        @Override
        public void updateStatus(int n) {
            this.active = ((BeaconMenu)BeaconScreen.this.menu).hasPayment() && BeaconScreen.this.primary != null;
        }
    }

    class BeaconCancelButton
    extends BeaconSpriteScreenButton {
        public BeaconCancelButton(int n, int n2) {
            super(n, n2, 112, 220, CommonComponents.GUI_CANCEL);
        }

        @Override
        public void onPress() {
            BeaconScreen.access$300((BeaconScreen)BeaconScreen.this).player.closeContainer();
        }

        @Override
        public void updateStatus(int n) {
        }
    }

    class BeaconPowerButton
    extends BeaconScreenButton {
        private final boolean isPrimary;
        protected final int tier;
        private MobEffect effect;
        private TextureAtlasSprite sprite;
        private Component tooltip;

        public BeaconPowerButton(int n, int n2, MobEffect mobEffect, boolean bl, int n3) {
            super(n, n2);
            this.isPrimary = bl;
            this.tier = n3;
            this.setEffect(mobEffect);
        }

        protected void setEffect(MobEffect mobEffect) {
            this.effect = mobEffect;
            this.sprite = Minecraft.getInstance().getMobEffectTextures().get(mobEffect);
            this.tooltip = this.createEffectDescription(mobEffect);
        }

        protected MutableComponent createEffectDescription(MobEffect mobEffect) {
            return new TranslatableComponent(mobEffect.getDescriptionId());
        }

        @Override
        public void onPress() {
            if (this.isSelected()) {
                return;
            }
            if (this.isPrimary) {
                BeaconScreen.this.primary = this.effect;
            } else {
                BeaconScreen.this.secondary = this.effect;
            }
            BeaconScreen.this.updateButtons();
        }

        @Override
        public void renderToolTip(PoseStack poseStack, int n, int n2) {
            BeaconScreen.this.renderTooltip(poseStack, this.tooltip, n, n2);
        }

        @Override
        protected void renderIcon(PoseStack poseStack) {
            RenderSystem.setShaderTexture(0, this.sprite.atlas().location());
            BeaconPowerButton.blit(poseStack, this.x + 2, this.y + 2, this.getBlitOffset(), 18, 18, this.sprite);
        }

        @Override
        public void updateStatus(int n) {
            this.active = this.tier < n;
            this.setSelected(this.effect == (this.isPrimary ? BeaconScreen.this.primary : BeaconScreen.this.secondary));
        }

        @Override
        protected MutableComponent createNarrationMessage() {
            return this.createEffectDescription(this.effect);
        }
    }

    class BeaconUpgradePowerButton
    extends BeaconPowerButton {
        public BeaconUpgradePowerButton(int n, int n2, MobEffect mobEffect) {
            super(n, n2, mobEffect, false, 3);
        }

        @Override
        protected MutableComponent createEffectDescription(MobEffect mobEffect) {
            return new TranslatableComponent(mobEffect.getDescriptionId()).append(" II");
        }

        @Override
        public void updateStatus(int n) {
            if (BeaconScreen.this.primary != null) {
                this.visible = true;
                this.setEffect(BeaconScreen.this.primary);
                super.updateStatus(n);
            } else {
                this.visible = false;
            }
        }
    }

    abstract class BeaconSpriteScreenButton
    extends BeaconScreenButton {
        private final int iconX;
        private final int iconY;

        protected BeaconSpriteScreenButton(int n, int n2, int n3, int n4, Component component) {
            super(n, n2, component);
            this.iconX = n3;
            this.iconY = n4;
        }

        @Override
        protected void renderIcon(PoseStack poseStack) {
            this.blit(poseStack, this.x + 2, this.y + 2, this.iconX, this.iconY, 18, 18);
        }

        @Override
        public void renderToolTip(PoseStack poseStack, int n, int n2) {
            BeaconScreen.this.renderTooltip(poseStack, BeaconScreen.this.title, n, n2);
        }
    }

    static abstract class BeaconScreenButton
    extends AbstractButton
    implements BeaconButton {
        private boolean selected;

        protected BeaconScreenButton(int n, int n2) {
            super(n, n2, 22, 22, TextComponent.EMPTY);
        }

        protected BeaconScreenButton(int n, int n2, Component component) {
            super(n, n2, 22, 22, component);
        }

        @Override
        public void renderButton(PoseStack poseStack, int n, int n2, float f) {
            RenderSystem.setShader(GameRenderer::getPositionTexShader);
            RenderSystem.setShaderTexture(0, BEACON_LOCATION);
            RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
            int n3 = 219;
            int n4 = 0;
            if (!this.active) {
                n4 += this.width * 2;
            } else if (this.selected) {
                n4 += this.width * 1;
            } else if (this.isHovered()) {
                n4 += this.width * 3;
            }
            this.blit(poseStack, this.x, this.y, n4, 219, this.width, this.height);
            this.renderIcon(poseStack);
        }

        protected abstract void renderIcon(PoseStack var1);

        public boolean isSelected() {
            return this.selected;
        }

        public void setSelected(boolean bl) {
            this.selected = bl;
        }

        @Override
        public boolean isShowingTooltip() {
            return this.isHovered;
        }

        @Override
        public void updateNarration(NarrationElementOutput narrationElementOutput) {
            this.defaultButtonNarrationText(narrationElementOutput);
        }
    }

}

