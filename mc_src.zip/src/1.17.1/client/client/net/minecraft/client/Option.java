/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package net.minecraft.client;

import com.google.common.collect.ImmutableList;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.platform.Window;
import java.util.Arrays;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import net.minecraft.ChatFormatting;
import net.minecraft.client.AmbientOcclusionStatus;
import net.minecraft.client.AttackIndicatorStatus;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.CycleOption;
import net.minecraft.client.GraphicsStatus;
import net.minecraft.client.LogaritmicProgressOption;
import net.minecraft.client.Minecraft;
import net.minecraft.client.NarratorStatus;
import net.minecraft.client.Options;
import net.minecraft.client.ParticleStatus;
import net.minecraft.client.ProgressOption;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.chat.NarratorChatListener;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.renderer.GpuWarnlistManager;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.ChatVisiblity;

public abstract class Option {
    protected static final int OPTIONS_TOOLTIP_WIDTH = 200;
    public static final ProgressOption BIOME_BLEND_RADIUS = new ProgressOption("options.biomeBlendRadius", 0.0, 7.0, 1.0f, options -> options.biomeBlendRadius, (options, d) -> {
        options.biomeBlendRadius = Mth.clamp((int)d.doubleValue(), 0, 7);
        Minecraft.getInstance().levelRenderer.allChanged();
    }, (options, progressOption) -> {
        double d = progressOption.get((Options)options);
        int n = (int)d * 2 + 1;
        return progressOption.genericValueLabel(new TranslatableComponent("options.biomeBlendRadius." + n));
    });
    public static final ProgressOption CHAT_HEIGHT_FOCUSED = new ProgressOption("options.chat.height.focused", 0.0, 1.0, 0.0f, options -> options.chatHeightFocused, (options, d) -> {
        options.chatHeightFocused = d;
        Minecraft.getInstance().gui.getChat().rescaleChat();
    }, (options, progressOption) -> {
        double d = progressOption.toPct(progressOption.get((Options)options));
        return progressOption.pixelValueLabel(ChatComponent.getHeight(d));
    });
    public static final ProgressOption CHAT_HEIGHT_UNFOCUSED = new ProgressOption("options.chat.height.unfocused", 0.0, 1.0, 0.0f, options -> options.chatHeightUnfocused, (options, d) -> {
        options.chatHeightUnfocused = d;
        Minecraft.getInstance().gui.getChat().rescaleChat();
    }, (options, progressOption) -> {
        double d = progressOption.toPct(progressOption.get((Options)options));
        return progressOption.pixelValueLabel(ChatComponent.getHeight(d));
    });
    public static final ProgressOption CHAT_OPACITY = new ProgressOption("options.chat.opacity", 0.0, 1.0, 0.0f, options -> options.chatOpacity, (options, d) -> {
        options.chatOpacity = d;
        Minecraft.getInstance().gui.getChat().rescaleChat();
    }, (options, progressOption) -> {
        double d = progressOption.toPct(progressOption.get((Options)options));
        return progressOption.percentValueLabel(d * 0.9 + 0.1);
    });
    public static final ProgressOption CHAT_SCALE = new ProgressOption("options.chat.scale", 0.0, 1.0, 0.0f, options -> options.chatScale, (options, d) -> {
        options.chatScale = d;
        Minecraft.getInstance().gui.getChat().rescaleChat();
    }, (options, progressOption) -> {
        double d = progressOption.toPct(progressOption.get((Options)options));
        if (d == 0.0) {
            return CommonComponents.optionStatus(progressOption.getCaption(), false);
        }
        return progressOption.percentValueLabel(d);
    });
    public static final ProgressOption CHAT_WIDTH = new ProgressOption("options.chat.width", 0.0, 1.0, 0.0f, options -> options.chatWidth, (options, d) -> {
        options.chatWidth = d;
        Minecraft.getInstance().gui.getChat().rescaleChat();
    }, (options, progressOption) -> {
        double d = progressOption.toPct(progressOption.get((Options)options));
        return progressOption.pixelValueLabel(ChatComponent.getWidth(d));
    });
    public static final ProgressOption CHAT_LINE_SPACING = new ProgressOption("options.chat.line_spacing", 0.0, 1.0, 0.0f, options -> options.chatLineSpacing, (options, d) -> {
        options.chatLineSpacing = d;
    }, (options, progressOption) -> progressOption.percentValueLabel(progressOption.toPct(progressOption.get((Options)options))));
    public static final ProgressOption CHAT_DELAY = new ProgressOption("options.chat.delay_instant", 0.0, 6.0, 0.1f, options -> options.chatDelay, (options, d) -> {
        options.chatDelay = d;
    }, (options, progressOption) -> {
        double d = progressOption.get((Options)options);
        if (d <= 0.0) {
            return new TranslatableComponent("options.chat.delay_none");
        }
        return new TranslatableComponent("options.chat.delay", String.format("%.1f", d));
    });
    public static final ProgressOption FOV = new ProgressOption("options.fov", 30.0, 110.0, 1.0f, options -> options.fov, (options, d) -> {
        options.fov = d;
        Minecraft.getInstance().levelRenderer.needsUpdate();
    }, (options, progressOption) -> {
        double d = progressOption.get((Options)options);
        if (d == 70.0) {
            return progressOption.genericValueLabel(new TranslatableComponent("options.fov.min"));
        }
        if (d == progressOption.getMaxValue()) {
            return progressOption.genericValueLabel(new TranslatableComponent("options.fov.max"));
        }
        return progressOption.genericValueLabel((int)d);
    });
    private static final Component ACCESSIBILITY_TOOLTIP_FOV_EFFECT = new TranslatableComponent("options.fovEffectScale.tooltip");
    public static final ProgressOption FOV_EFFECTS_SCALE = new ProgressOption("options.fovEffectScale", 0.0, 1.0, 0.0f, options -> Math.pow(options.fovEffectScale, 2.0), (options, d) -> {
        options.fovEffectScale = (float)Math.sqrt(d);
    }, (options, progressOption) -> {
        double d = progressOption.toPct(progressOption.get((Options)options));
        if (d == 0.0) {
            return progressOption.genericValueLabel(CommonComponents.OPTION_OFF);
        }
        return progressOption.percentValueLabel(d);
    }, minecraft -> minecraft.font.split(ACCESSIBILITY_TOOLTIP_FOV_EFFECT, 200));
    private static final Component ACCESSIBILITY_TOOLTIP_SCREEN_EFFECT = new TranslatableComponent("options.screenEffectScale.tooltip");
    public static final ProgressOption SCREEN_EFFECTS_SCALE = new ProgressOption("options.screenEffectScale", 0.0, 1.0, 0.0f, options -> options.screenEffectScale, (options, d) -> {
        options.screenEffectScale = d.floatValue();
    }, (options, progressOption) -> {
        double d = progressOption.toPct(progressOption.get((Options)options));
        if (d == 0.0) {
            return progressOption.genericValueLabel(CommonComponents.OPTION_OFF);
        }
        return progressOption.percentValueLabel(d);
    }, minecraft -> minecraft.font.split(ACCESSIBILITY_TOOLTIP_SCREEN_EFFECT, 200));
    public static final ProgressOption FRAMERATE_LIMIT = new ProgressOption("options.framerateLimit", 10.0, 260.0, 10.0f, options -> options.framerateLimit, (options, d) -> {
        options.framerateLimit = (int)d.doubleValue();
        Minecraft.getInstance().getWindow().setFramerateLimit(options.framerateLimit);
    }, (options, progressOption) -> {
        double d = progressOption.get((Options)options);
        if (d == progressOption.getMaxValue()) {
            return progressOption.genericValueLabel(new TranslatableComponent("options.framerateLimit.max"));
        }
        return progressOption.genericValueLabel(new TranslatableComponent("options.framerate", (int)d));
    });
    public static final ProgressOption GAMMA = new ProgressOption("options.gamma", 0.0, 1.0, 0.0f, options -> options.gamma, (options, d) -> {
        options.gamma = d;
    }, (options, progressOption) -> {
        double d = progressOption.toPct(progressOption.get((Options)options));
        if (d == 0.0) {
            return progressOption.genericValueLabel(new TranslatableComponent("options.gamma.min"));
        }
        if (d == 1.0) {
            return progressOption.genericValueLabel(new TranslatableComponent("options.gamma.max"));
        }
        return progressOption.percentAddValueLabel((int)(d * 100.0));
    });
    public static final ProgressOption MIPMAP_LEVELS = new ProgressOption("options.mipmapLevels", 0.0, 4.0, 1.0f, options -> options.mipmapLevels, (options, d) -> {
        options.mipmapLevels = (int)d.doubleValue();
    }, (options, progressOption) -> {
        double d = progressOption.get((Options)options);
        if (d == 0.0) {
            return CommonComponents.optionStatus(progressOption.getCaption(), false);
        }
        return progressOption.genericValueLabel((int)d);
    });
    public static final ProgressOption MOUSE_WHEEL_SENSITIVITY = new LogaritmicProgressOption("options.mouseWheelSensitivity", 0.01, 10.0, 0.01f, options -> options.mouseWheelSensitivity, (options, d) -> {
        options.mouseWheelSensitivity = d;
    }, (options, progressOption) -> {
        double d = progressOption.toPct(progressOption.get((Options)options));
        return progressOption.genericValueLabel(new TextComponent(String.format("%.2f", progressOption.toValue(d))));
    });
    public static final CycleOption<Boolean> RAW_MOUSE_INPUT = CycleOption.createOnOff("options.rawMouseInput", options -> options.rawMouseInput, (options, option, bl) -> {
        options.rawMouseInput = bl;
        Window window = Minecraft.getInstance().getWindow();
        if (window != null) {
            window.updateRawMouseInput((boolean)bl);
        }
    });
    public static final ProgressOption RENDER_DISTANCE = new ProgressOption("options.renderDistance", 2.0, 16.0, 1.0f, options -> options.renderDistance, (options, d) -> {
        options.renderDistance = (int)d.doubleValue();
        Minecraft.getInstance().levelRenderer.needsUpdate();
    }, (options, progressOption) -> {
        double d = progressOption.get((Options)options);
        return progressOption.genericValueLabel(new TranslatableComponent("options.chunks", (int)d));
    });
    public static final ProgressOption ENTITY_DISTANCE_SCALING = new ProgressOption("options.entityDistanceScaling", 0.5, 5.0, 0.25f, options -> options.entityDistanceScaling, (options, d) -> {
        options.entityDistanceScaling = (float)d.doubleValue();
    }, (options, progressOption) -> {
        double d = progressOption.get((Options)options);
        return progressOption.percentValueLabel(d);
    });
    public static final ProgressOption SENSITIVITY = new ProgressOption("options.sensitivity", 0.0, 1.0, 0.0f, options -> options.sensitivity, (options, d) -> {
        options.sensitivity = d;
    }, (options, progressOption) -> {
        double d = progressOption.toPct(progressOption.get((Options)options));
        if (d == 0.0) {
            return progressOption.genericValueLabel(new TranslatableComponent("options.sensitivity.min"));
        }
        if (d == 1.0) {
            return progressOption.genericValueLabel(new TranslatableComponent("options.sensitivity.max"));
        }
        return progressOption.percentValueLabel(2.0 * d);
    });
    public static final ProgressOption TEXT_BACKGROUND_OPACITY = new ProgressOption("options.accessibility.text_background_opacity", 0.0, 1.0, 0.0f, options -> options.textBackgroundOpacity, (options, d) -> {
        options.textBackgroundOpacity = d;
        Minecraft.getInstance().gui.getChat().rescaleChat();
    }, (options, progressOption) -> progressOption.percentValueLabel(progressOption.toPct(progressOption.get((Options)options))));
    public static final CycleOption<AmbientOcclusionStatus> AMBIENT_OCCLUSION = CycleOption.create("options.ao", AmbientOcclusionStatus.values(), ambientOcclusionStatus -> new TranslatableComponent(ambientOcclusionStatus.getKey()), options -> options.ambientOcclusion, (options, option, ambientOcclusionStatus) -> {
        options.ambientOcclusion = ambientOcclusionStatus;
        Minecraft.getInstance().levelRenderer.allChanged();
    });
    public static final CycleOption<AttackIndicatorStatus> ATTACK_INDICATOR = CycleOption.create("options.attackIndicator", AttackIndicatorStatus.values(), attackIndicatorStatus -> new TranslatableComponent(attackIndicatorStatus.getKey()), options -> options.attackIndicator, (options, option, attackIndicatorStatus) -> {
        options.attackIndicator = attackIndicatorStatus;
    });
    public static final CycleOption<ChatVisiblity> CHAT_VISIBILITY = CycleOption.create("options.chat.visibility", ChatVisiblity.values(), chatVisiblity -> new TranslatableComponent(chatVisiblity.getKey()), options -> options.chatVisibility, (options, option, chatVisiblity) -> {
        options.chatVisibility = chatVisiblity;
    });
    private static final Component GRAPHICS_TOOLTIP_FAST = new TranslatableComponent("options.graphics.fast.tooltip");
    private static final Component GRAPHICS_TOOLTIP_FABULOUS = new TranslatableComponent("options.graphics.fabulous.tooltip", new TranslatableComponent("options.graphics.fabulous").withStyle(ChatFormatting.ITALIC));
    private static final Component GRAPHICS_TOOLTIP_FANCY = new TranslatableComponent("options.graphics.fancy.tooltip");
    public static final CycleOption<GraphicsStatus> GRAPHICS = CycleOption.create("options.graphics", Arrays.asList(GraphicsStatus.values()), Stream.of(GraphicsStatus.values()).filter(graphicsStatus -> graphicsStatus != GraphicsStatus.FABULOUS).collect(Collectors.toList()), () -> Minecraft.getInstance().getGpuWarnlistManager().isSkippingFabulous(), graphicsStatus -> {
        TranslatableComponent translatableComponent = new TranslatableComponent(graphicsStatus.getKey());
        if (graphicsStatus == GraphicsStatus.FABULOUS) {
            return translatableComponent.withStyle(ChatFormatting.ITALIC);
        }
        return translatableComponent;
    }, options -> options.graphicsMode, (options, option, graphicsStatus) -> {
        Minecraft minecraft = Minecraft.getInstance();
        GpuWarnlistManager gpuWarnlistManager = minecraft.getGpuWarnlistManager();
        if (graphicsStatus == GraphicsStatus.FABULOUS && gpuWarnlistManager.willShowWarning()) {
            gpuWarnlistManager.showWarning();
            return;
        }
        options.graphicsMode = graphicsStatus;
        minecraft.levelRenderer.allChanged();
    }).setTooltip(minecraft -> {
        List<FormattedCharSequence> list = minecraft.font.split(GRAPHICS_TOOLTIP_FAST, 200);
        List<FormattedCharSequence> list2 = minecraft.font.split(GRAPHICS_TOOLTIP_FANCY, 200);
        List<FormattedCharSequence> list3 = minecraft.font.split(GRAPHICS_TOOLTIP_FABULOUS, 200);
        return graphicsStatus -> {
            switch (graphicsStatus) {
                case FANCY: {
                    return list2;
                }
                case FAST: {
                    return list;
                }
                case FABULOUS: {
                    return list3;
                }
            }
            return ImmutableList.of();
        };
    });
    public static final CycleOption GUI_SCALE = CycleOption.create("options.guiScale", () -> IntStream.rangeClosed(0, Minecraft.getInstance().getWindow().calculateScale(0, Minecraft.getInstance().isEnforceUnicode())).boxed().collect(Collectors.toList()), n -> n == 0 ? new TranslatableComponent("options.guiScale.auto") : new TextComponent(Integer.toString(n)), options -> options.guiScale, (options, option, n) -> {
        options.guiScale = n;
    });
    public static final CycleOption<HumanoidArm> MAIN_HAND = CycleOption.create("options.mainHand", HumanoidArm.values(), HumanoidArm::getName, options -> options.mainHand, (options, option, humanoidArm) -> {
        options.mainHand = humanoidArm;
        options.broadcastOptions();
    });
    public static final CycleOption<NarratorStatus> NARRATOR = CycleOption.create("options.narrator", NarratorStatus.values(), narratorStatus -> {
        if (NarratorChatListener.INSTANCE.isActive()) {
            return narratorStatus.getName();
        }
        return new TranslatableComponent("options.narrator.notavailable");
    }, options -> options.narratorStatus, (options, option, narratorStatus) -> {
        options.narratorStatus = narratorStatus;
        NarratorChatListener.INSTANCE.updateNarratorStatus((NarratorStatus)((Object)narratorStatus));
    });
    public static final CycleOption<ParticleStatus> PARTICLES = CycleOption.create("options.particles", ParticleStatus.values(), particleStatus -> new TranslatableComponent(particleStatus.getKey()), options -> options.particles, (options, option, particleStatus) -> {
        options.particles = particleStatus;
    });
    public static final CycleOption<CloudStatus> RENDER_CLOUDS = CycleOption.create("options.renderClouds", CloudStatus.values(), cloudStatus -> new TranslatableComponent(cloudStatus.getKey()), options -> options.renderClouds, (options, option, cloudStatus) -> {
        RenderTarget renderTarget;
        options.renderClouds = cloudStatus;
        if (Minecraft.useShaderTransparency() && (renderTarget = Minecraft.getInstance().levelRenderer.getCloudsTarget()) != null) {
            renderTarget.clear(Minecraft.ON_OSX);
        }
    });
    public static final CycleOption<Boolean> TEXT_BACKGROUND = CycleOption.createBinaryOption("options.accessibility.text_background", new TranslatableComponent("options.accessibility.text_background.chat"), new TranslatableComponent("options.accessibility.text_background.everywhere"), options -> options.backgroundForChatOnly, (options, option, bl) -> {
        options.backgroundForChatOnly = bl;
    });
    private static final Component CHAT_TOOLTIP_HIDE_MATCHED_NAMES = new TranslatableComponent("options.hideMatchedNames.tooltip");
    public static final CycleOption<Boolean> AUTO_JUMP = CycleOption.createOnOff("options.autoJump", options -> options.autoJump, (options, option, bl) -> {
        options.autoJump = bl;
    });
    public static final CycleOption<Boolean> AUTO_SUGGESTIONS = CycleOption.createOnOff("options.autoSuggestCommands", options -> options.autoSuggestions, (options, option, bl) -> {
        options.autoSuggestions = bl;
    });
    public static final CycleOption<Boolean> CHAT_COLOR = CycleOption.createOnOff("options.chat.color", options -> options.chatColors, (options, option, bl) -> {
        options.chatColors = bl;
    });
    public static final CycleOption<Boolean> HIDE_MATCHED_NAMES = CycleOption.createOnOff("options.hideMatchedNames", CHAT_TOOLTIP_HIDE_MATCHED_NAMES, options -> options.hideMatchedNames, (options, option, bl) -> {
        options.hideMatchedNames = bl;
    });
    public static final CycleOption<Boolean> CHAT_LINKS = CycleOption.createOnOff("options.chat.links", options -> options.chatLinks, (options, option, bl) -> {
        options.chatLinks = bl;
    });
    public static final CycleOption<Boolean> CHAT_LINKS_PROMPT = CycleOption.createOnOff("options.chat.links.prompt", options -> options.chatLinksPrompt, (options, option, bl) -> {
        options.chatLinksPrompt = bl;
    });
    public static final CycleOption<Boolean> DISCRETE_MOUSE_SCROLL = CycleOption.createOnOff("options.discrete_mouse_scroll", options -> options.discreteMouseScroll, (options, option, bl) -> {
        options.discreteMouseScroll = bl;
    });
    public static final CycleOption<Boolean> ENABLE_VSYNC = CycleOption.createOnOff("options.vsync", options -> options.enableVsync, (options, option, bl) -> {
        options.enableVsync = bl;
        if (Minecraft.getInstance().getWindow() != null) {
            Minecraft.getInstance().getWindow().updateVsync(options.enableVsync);
        }
    });
    public static final CycleOption<Boolean> ENTITY_SHADOWS = CycleOption.createOnOff("options.entityShadows", options -> options.entityShadows, (options, option, bl) -> {
        options.entityShadows = bl;
    });
    public static final CycleOption<Boolean> FORCE_UNICODE_FONT = CycleOption.createOnOff("options.forceUnicodeFont", options -> options.forceUnicodeFont, (options, option, bl) -> {
        options.forceUnicodeFont = bl;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.getWindow() != null) {
            minecraft.selectMainFont((boolean)bl);
            minecraft.resizeDisplay();
        }
    });
    public static final CycleOption<Boolean> INVERT_MOUSE = CycleOption.createOnOff("options.invertMouse", options -> options.invertYMouse, (options, option, bl) -> {
        options.invertYMouse = bl;
    });
    public static final CycleOption<Boolean> REALMS_NOTIFICATIONS = CycleOption.createOnOff("options.realmsNotifications", options -> options.realmsNotifications, (options, option, bl) -> {
        options.realmsNotifications = bl;
    });
    public static final CycleOption<Boolean> REDUCED_DEBUG_INFO = CycleOption.createOnOff("options.reducedDebugInfo", options -> options.reducedDebugInfo, (options, option, bl) -> {
        options.reducedDebugInfo = bl;
    });
    public static final CycleOption<Boolean> SHOW_SUBTITLES = CycleOption.createOnOff("options.showSubtitles", options -> options.showSubtitles, (options, option, bl) -> {
        options.showSubtitles = bl;
    });
    public static final CycleOption<Boolean> SNOOPER_ENABLED = CycleOption.createOnOff("options.snooper", options -> {
        if (options.snooperEnabled) {
            // empty if block
        }
        return false;
    }, (options, option, bl) -> {
        options.snooperEnabled = bl;
    });
    private static final Component MOVEMENT_TOGGLE = new TranslatableComponent("options.key.toggle");
    private static final Component MOVEMENT_HOLD = new TranslatableComponent("options.key.hold");
    public static final CycleOption<Boolean> TOGGLE_CROUCH = CycleOption.createBinaryOption("key.sneak", MOVEMENT_TOGGLE, MOVEMENT_HOLD, options -> options.toggleCrouch, (options, option, bl) -> {
        options.toggleCrouch = bl;
    });
    public static final CycleOption<Boolean> TOGGLE_SPRINT = CycleOption.createBinaryOption("key.sprint", MOVEMENT_TOGGLE, MOVEMENT_HOLD, options -> options.toggleSprint, (options, option, bl) -> {
        options.toggleSprint = bl;
    });
    public static final CycleOption<Boolean> TOUCHSCREEN = CycleOption.createOnOff("options.touchscreen", options -> options.touchscreen, (options, option, bl) -> {
        options.touchscreen = bl;
    });
    public static final CycleOption<Boolean> USE_FULLSCREEN = CycleOption.createOnOff("options.fullscreen", options -> options.fullscreen, (options, option, bl) -> {
        options.fullscreen = bl;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.getWindow() != null && minecraft.getWindow().isFullscreen() != options.fullscreen) {
            minecraft.getWindow().toggleFullScreen();
            options.fullscreen = minecraft.getWindow().isFullscreen();
        }
    });
    public static final CycleOption<Boolean> VIEW_BOBBING = CycleOption.createOnOff("options.viewBobbing", options -> options.bobView, (options, option, bl) -> {
        options.bobView = bl;
    });
    private static final Component ACCESSIBILITY_TOOLTIP_DARK_MOJANG_BACKGROUND = new TranslatableComponent("options.darkMojangStudiosBackgroundColor.tooltip");
    public static final CycleOption<Boolean> DARK_MOJANG_STUDIOS_BACKGROUND_COLOR = CycleOption.createOnOff("options.darkMojangStudiosBackgroundColor", ACCESSIBILITY_TOOLTIP_DARK_MOJANG_BACKGROUND, options -> options.darkMojangStudiosBackground, (options, option, bl) -> {
        options.darkMojangStudiosBackground = bl;
    });
    private final Component caption;

    public Option(String string) {
        this.caption = new TranslatableComponent(string);
    }

    public abstract AbstractWidget createButton(Options var1, int var2, int var3, int var4);

    protected Component getCaption() {
        return this.caption;
    }

    protected Component pixelValueLabel(int n) {
        return new TranslatableComponent("options.pixel_value", this.getCaption(), n);
    }

    protected Component percentValueLabel(double d) {
        return new TranslatableComponent("options.percent_value", this.getCaption(), (int)(d * 100.0));
    }

    protected Component percentAddValueLabel(int n) {
        return new TranslatableComponent("options.percent_add_value", this.getCaption(), n);
    }

    protected Component genericValueLabel(Component component) {
        return new TranslatableComponent("options.generic_value", this.getCaption(), component);
    }

    protected Component genericValueLabel(int n) {
        return this.genericValueLabel(new TextComponent(Integer.toString(n)));
    }

}

