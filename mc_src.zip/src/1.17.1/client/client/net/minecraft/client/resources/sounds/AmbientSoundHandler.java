/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.resources.sounds;

public interface AmbientSoundHandler {
    public void tick();
}

