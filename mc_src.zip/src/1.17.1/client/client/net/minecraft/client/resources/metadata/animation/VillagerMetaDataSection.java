/*
 * Decompiled with CFR 0.146.
 */
package net.minecraft.client.resources.metadata.animation;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import net.minecraft.client.resources.metadata.animation.VillagerMetadataSectionSerializer;

public class VillagerMetaDataSection {
    public static final VillagerMetadataSectionSerializer SERIALIZER = new VillagerMetadataSectionSerializer();
    public static final String SECTION_NAME = "villager";
    private final Hat hat;

    public VillagerMetaDataSection(Hat hat) {
        this.hat = hat;
    }

    public Hat getHat() {
        return this.hat;
    }

    public static final class Hat
    extends Enum<Hat> {
        public static final /* enum */ Hat NONE = new Hat("none");
        public static final /* enum */ Hat PARTIAL = new Hat("partial");
        public static final /* enum */ Hat FULL = new Hat("full");
        private static final Map<String, Hat> BY_NAME;
        private final String name;
        private static final /* synthetic */ Hat[] $VALUES;

        public static Hat[] values() {
            return (Hat[])$VALUES.clone();
        }

        public static Hat valueOf(String string) {
            return Enum.valueOf(Hat.class, string);
        }

        private Hat(String string2) {
            this.name = string2;
        }

        public String getName() {
            return this.name;
        }

        public static Hat getByName(String string) {
            return BY_NAME.getOrDefault(string, NONE);
        }

        private static /* synthetic */ Hat[] $values() {
            return new Hat[]{NONE, PARTIAL, FULL};
        }

        static {
            $VALUES = Hat.$values();
            BY_NAME = Arrays.stream(Hat.values()).collect(Collectors.toMap(Hat::getName, hat -> hat));
        }
    }

}

